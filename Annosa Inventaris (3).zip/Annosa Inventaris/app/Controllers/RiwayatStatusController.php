<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\RiwayatStatusModel;
use App\Models\BarangModel;
use App\Models\UserModel;

class RiwayatStatusController extends BaseController
{
    protected $riwayatModel;
    protected $session;

    public function __construct()
    {
        $this->riwayatModel = new RiwayatStatusModel();
        $this->session = session();
    }

    // ✅ Lihat semua riwayat
    public function index()
    {
        $this->checkLogin();

        $status = $this->request->getGet('status');
        $cari = $this->request->getGet('search');

        if ($status) {
            $data['riwayat'] = $this->riwayatModel->getByStatusBaru($status);
        } elseif ($cari) {
            $data['riwayat'] = $this->riwayatModel->cariByBarang($cari);
        } else {
            $data['riwayat'] = $this->riwayatModel->getFullRiwayat();
        }

        return view('riwayat/index', $data);
    }

    // ✅ Tambah riwayat status (manual)
    public function create()
    {
        $this->checkLogin();

        $data['barang'] = (new BarangModel())->findAll();
        return view('riwayat/create', $data);
    }

    // ✅ Simpan riwayat status
    public function store()
    {
        $this->checkLogin();

        $data = $this->request->getPost();
        $data['user_id'] = $this->session->get('id_user');

        $this->riwayatModel->insert($data);
        return redirect()->to('/riwayat')->with('success', 'Riwayat status berhasil ditambahkan.');
    }

    // ✅ Riwayat per barang
    public function byBarang($kode_barang)
    {
        $this->checkLogin();

        $data['riwayat'] = $this->riwayatModel->getRiwayatByBarang($kode_barang);
        $data['barang'] = (new BarangModel())->find($kode_barang);

        return view('riwayat/detail', $data);
    }

    // ✅ Riwayat antara dua tanggal
    public function byTanggal()
    {
        $this->checkLogin();

        $start = $this->request->getGet('start');
        $end   = $this->request->getGet('end');

        if ($start && $end) {
            $data['riwayat'] = $this->riwayatModel->getRiwayatBetween($start, $end);
        } else {
            $data['riwayat'] = [];
        }

        return view('riwayat/tanggal', $data);
    }

    // ✅ Proteksi login
    private function checkLogin()
    {
        if (!$this->session->get('is_logged_in')) {
            return redirect()->to('/login')->send();
        }
    }
}
