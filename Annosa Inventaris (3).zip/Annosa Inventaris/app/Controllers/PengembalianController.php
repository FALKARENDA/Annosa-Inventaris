<?php

namespace App\Controllers;

use App\Models\PengembalianModel;
use App\Models\PeminjamanModel;

class PengembalianController extends BaseController
{
    protected $pengembalianModel;
    protected $peminjamanModel;

    public function __construct()
    {
        $this->pengembalianModel = new PengembalianModel();
        $this->peminjamanModel   = new PeminjamanModel();
    }

    public function index()
    {
        $data['pengembalian'] = $this->pengembalianModel->getWithPeminjaman();
        return view('pengembalian/index', $data);
    }

    public function create()
    {
        $data['peminjaman'] = $this->peminjamanModel->where('status', 'Sedang Dipinjam')->findAll();
        return view('pengembalian/create', $data);
    }

    public function store()
    {
        $this->pengembalianModel->save([
            'kode_pengembalian'    => $this->request->getPost('kode_pengembalian'),
            'peminjaman_id'        => $this->request->getPost('peminjaman_id'),
            'tanggal_pengembalian' => $this->request->getPost('tanggal_pengembalian'),
            'jumlah_kembali'       => $this->request->getPost('jumlah_kembali'),
            'kondisi_kembali'      => $this->request->getPost('kondisi_kembali'),
            'catatan_kembali'      => $this->request->getPost('catatan_kembali'),
            'status'               => 'Sudah Dikembalikan',
            'petugas_terima'       => session()->get('username') ?? 'admin',
            'verifikasi'           => 1
        ]);

        // Optional: update status di peminjaman
        $this->peminjamanModel->update($this->request->getPost('peminjaman_id'), [
            'status' => 'Sudah Dikembalikan',
            'verifikasi' => 1
        ]);

        return redirect()->to('/pengembalian')->with('success', 'Pengembalian berhasil disimpan');
    }

    public function edit($id)
    {
        $data['pengembalian'] = $this->pengembalianModel->find($id);
        $data['peminjaman']   = $this->peminjamanModel->findAll();
        return view('pengembalian/edit', $data);
    }

    public function update($id)
    {
        $this->pengembalianModel->update($id, [
            'kode_pengembalian'    => $this->request->getPost('kode_pengembalian'),
            'peminjaman_id'        => $this->request->getPost('peminjaman_id'),
            'tanggal_pengembalian' => $this->request->getPost('tanggal_pengembalian'),
            'jumlah_kembali'       => $this->request->getPost('jumlah_kembali'),
            'kondisi_kembali'      => $this->request->getPost('kondisi_kembali'),
            'catatan_kembali'      => $this->request->getPost('catatan_kembali'),
            'status'               => $this->request->getPost('status'),
            'petugas_terima'       => session()->get('username') ?? 'admin',
            'verifikasi'           => $this->request->getPost('verifikasi') ?? 0
        ]);

        return redirect()->to('/pengembalian')->with('success', 'Data pengembalian diperbarui');
    }

    public function delete($id)
    {
        $this->pengembalianModel->delete($id);
        return redirect()->to('/pengembalian')->with('success', 'Data pengembalian dihapus');
    }
}
