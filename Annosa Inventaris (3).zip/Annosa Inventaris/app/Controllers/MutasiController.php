<?php

namespace App\Controllers;

use App\Models\MutasiModel;
use App\Models\InventarisModel;
use App\Models\LokasiModel;

class MutasiController extends BaseController
{
    protected $mutasiModel;
    protected $inventarisModel;
    protected $lokasiModel;

    public function __construct()
    {
        $this->mutasiModel     = new MutasiModel();
        $this->inventarisModel = new InventarisModel();
        $this->lokasiModel     = new LokasiModel();
    }

  public function index()
{
    $data['mutasi']     = $this->mutasiModel->getWithRelasi();
    $data['lokasi']     = $this->lokasiModel->findAll();
    $data['inventaris'] = $this->inventarisModel->getWithBarangLokasi();

    return view('mutasi/index', $data);
}


    public function create()
    {
        $data['inventaris'] = $this->inventarisModel->getWithRelations();
        $data['lokasi']     = $this->lokasiModel->findAll();
        return view('mutasi/create', $data);
    }

    public function store()
    {
$this->mutasiModel->save([
    'inventaris_id'      => $this->request->getPost('inventaris_id'),
    'tanggal'            => $this->request->getPost('tanggal_mutasi'),
    'lokasi_awal_id'     => $this->request->getPost('lokasi_awal'),
    'lokasi_tujuan_id'   => $this->request->getPost('lokasi_tujuan'),
    'tahun_anggaran'     => $this->request->getPost('tahun_anggaran'),
    'keterangan'         => $this->request->getPost('keterangan')
]);


        return redirect()->to('/mutasi')->with('success', 'Data mutasi berhasil ditambahkan');
    }

    public function edit($id)
    {
        $data['mutasi']     = $this->mutasiModel->find($id);
        $data['inventaris'] = $this->inventarisModel->getWithRelations();
        $data['lokasi']     = $this->lokasiModel->findAll();
        return view('mutasi/edit', $data);
    }

    public function update($id)
    {
        $this->mutasiModel->update($id, [
            'inventaris_id'    => $this->request->getPost('inventaris_id'),
            'lokasi_asal_id'   => $this->request->getPost('lokasi_asal_id'),
            'lokasi_tujuan_id' => $this->request->getPost('lokasi_tujuan_id'),
            'tanggal'          => $this->request->getPost('tanggal'),
            'alasan'           => $this->request->getPost('alasan'),
            'petugas'          => session()->get('username') ?? 'admin',
            'status'           => $this->request->getPost('status')
        ]);

        return redirect()->to('/mutasi')->with('success', 'Data mutasi berhasil diperbarui');
    }

    public function delete($id)
    {
        $this->mutasiModel->delete($id);
        return redirect()->to('/mutasi')->with('success', 'Data mutasi berhasil dihapus');
    }
}
