<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\DokumenModel;
use App\Models\BarangModel;

class DokumenController extends BaseController
{
    protected $dokumenModel;
    protected $session;

    public function __construct()
    {
        $this->dokumenModel = new DokumenModel();
        $this->session = session();
    }

    // ✅ Lihat semua dokumen
    public function index()
    {
        $this->checkLogin();

        $tipe = $this->request->getGet('tipe');
        $cari = $this->request->getGet('search');

        if ($tipe) {
            $data['dokumen'] = $this->dokumenModel->getByTipe($tipe);
        } elseif ($cari) {
            $data['dokumen'] = $this->dokumenModel->cariByNamaBarang($cari);
        } else {
            $data['dokumen'] = $this->dokumenModel->getAllWithBarang();
        }

        return view('dokumen/index', $data);
    }

    // ✅ Form tambah dokumen
    public function create()
    {
        $this->checkLogin();
        $data['barang'] = (new BarangModel())->findAll();
        return view('dokumen/create', $data);
    }

    // ✅ Simpan dokumen baru (upload)
    public function store()
    {
        $this->checkLogin();

        $file = $this->request->getFile('file_dokumen');
        $data = $this->request->getPost();

        if ($file && $file->isValid()) {
            $namaFile = $file->getRandomName();
            $file->move('uploads/dokumen/', $namaFile);
            $data['url_file'] = 'uploads/dokumen/' . $namaFile;
        }

        $this->dokumenModel->insert($data);
        return redirect()->to('/dokumen')->with('success', 'Dokumen berhasil ditambahkan.');
    }

    // ✅ Form edit dokumen
    public function edit($id)
    {
        $this->checkLogin();

        $data['dokumen'] = $this->dokumenModel->find($id);
        $data['barang'] = (new BarangModel())->findAll();

        return view('dokumen/edit', $data);
    }

    // ✅ Simpan update dokumen
    public function update($id)
    {
        $this->checkLogin();

        $dokumen = $this->dokumenModel->find($id);
        $file = $this->request->getFile('file_dokumen');
        $data = $this->request->getPost();

        if ($file && $file->isValid()) {
            $namaFile = $file->getRandomName();
            $file->move('uploads/dokumen/', $namaFile);
            $data['url_file'] = 'uploads/dokumen/' . $namaFile;

            // hapus file lama
            if (file_exists($dokumen['url_file'])) {
                unlink($dokumen['url_file']);
            }
        }

        $this->dokumenModel->update($id, $data);
        return redirect()->to('/dokumen')->with('success', 'Dokumen berhasil diperbarui.');
    }

    // ✅ Hapus dokumen
    public function delete($id)
    {
        $this->checkLogin();

        $dokumen = $this->dokumenModel->find($id);
        if ($dokumen && file_exists($dokumen['url_file'])) {
            unlink($dokumen['url_file']);
        }

        $this->dokumenModel->delete($id);
        return redirect()->to('/dokumen')->with('success', 'Dokumen berhasil dihapus.');
    }

    // ✅ Dokumen berdasarkan barang
    public function byBarang($kode_barang)
    {
        $this->checkLogin();

        $data['dokumen'] = $this->dokumenModel->getDokumenByBarang($kode_barang);
        $data['barang'] = (new BarangModel())->find($kode_barang);

        return view('dokumen/detail', $data);
    }

    // ✅ Cek login
    private function checkLogin()
    {
        if (!$this->session->get('is_logged_in')) {
            return redirect()->to('/login')->send();
        }
    }
}
