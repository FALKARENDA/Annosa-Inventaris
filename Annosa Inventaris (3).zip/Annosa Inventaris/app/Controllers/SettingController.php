<?php

namespace App\Controllers;

use App\Models\SettingModel;

class SettingController extends BaseController
{
    protected $settingModel;

    public function __construct()
    {
        $this->settingModel = new SettingModel();
    }

    public function index()
    {
        $theme = $this->settingModel->where('key', 'theme')->first();
        $data['theme'] = $theme ? $theme['value'] : 'light';

        $data['tampilan'] = [
            [
                'type' => 'Epson',
                'jumlah' => '1 Unit',
                'kondisi' => 'Baik'
            ]
        ];

        return view('setting/index', $data);
    }

    public function theme()
    {
        $theme = $this->request->getPost('theme');
        $this->settingModel->updateOrInsert('theme', $theme);

        return redirect()->to('/setting')->with('success', 'Tema diperbarui');
    }

    public function update()
    {
        // Simpan pengaturan tampilan jika diperlukan
        return redirect()->to('/setting')->with('success', 'Tampilan diperbarui');
    }
}
