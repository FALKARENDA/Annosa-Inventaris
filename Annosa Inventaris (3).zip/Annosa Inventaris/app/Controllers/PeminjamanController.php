<?php

namespace App\Controllers;

use App\Models\PeminjamanModel;
use App\Models\InventarisModel;

class PeminjamanController extends BaseController
{
    protected $peminjamanModel;
    protected $inventarisModel;

    public function __construct()
    {
        $this->peminjamanModel = new PeminjamanModel();
        $this->inventarisModel = new InventarisModel();
    }

    public function index()
    {
        $data['peminjaman'] = $this->peminjamanModel->getWithInventaris();
        return view('peminjaman/index', $data);
    }

    public function create()
    {
        $data['inventaris'] = $this->inventarisModel->getWithRelations();
        return view('peminjaman/create', $data);
    }

    public function store()
    {
        $this->peminjamanModel->save([
            'kode_peminjaman'  => $this->request->getPost('kode_peminjaman'),
            'nama_peminjam'    => $this->request->getPost('nama_peminjam'),
            'nomor_identitas'  => $this->request->getPost('nomor_identitas'),
            'tanggal_pinjam'   => $this->request->getPost('tanggal_pinjam'),
            'tanggal_kembali'  => $this->request->getPost('tanggal_kembali'),
            'inventaris_id'    => $this->request->getPost('inventaris_id'),
            'jumlah'           => $this->request->getPost('jumlah'),
            'keperluan'        => $this->request->getPost('keperluan'),
            'status'           => 'Sedang Dipinjam',
            'petugas_input'    => session()->get('username') ?? 'admin',
            'verifikasi'       => 0
        ]);

        return redirect()->to('/peminjaman')->with('success', 'Data peminjaman berhasil ditambahkan');
    }

    public function edit($id)
    {
        $data['peminjaman'] = $this->peminjamanModel->find($id);
        $data['inventaris'] = $this->inventarisModel->getWithRelations();
        return view('peminjaman/edit', $data);
    }

    public function update($id)
    {
        $this->peminjamanModel->update($id, [
            'kode_peminjaman'  => $this->request->getPost('kode_peminjaman'),
            'nama_peminjam'    => $this->request->getPost('nama_peminjam'),
            'nomor_identitas'  => $this->request->getPost('nomor_identitas'),
            'tanggal_pinjam'   => $this->request->getPost('tanggal_pinjam'),
            'tanggal_kembali'  => $this->request->getPost('tanggal_kembali'),
            'inventaris_id'    => $this->request->getPost('inventaris_id'),
            'jumlah'           => $this->request->getPost('jumlah'),
            'keperluan'        => $this->request->getPost('keperluan'),
            'status'           => $this->request->getPost('status'),
            'petugas_input'    => session()->get('username') ?? 'admin',
            'verifikasi'       => $this->request->getPost('verifikasi') ?? 0
        ]);

        return redirect()->to('/peminjaman')->with('success', 'Data peminjaman berhasil diperbarui');
    }

    public function delete($id)
    {
        $this->peminjamanModel->delete($id);
        return redirect()->to('/peminjaman')->with('success', 'Data peminjaman berhasil dihapus');
    }
}
