<?php

namespace App\Controllers;

use App\Models\BarangModel;
use App\Models\InventarisModel;
use App\Models\UserModel;
use App\Models\PeminjamanModel;
use App\Models\PengembalianModel;
use App\Models\MutasiModel;
use App\Models\LogLoginModel;

class DashboardController extends BaseController
{
    public function __construct()
    {
        helper('url');

    }

    public function index()
    {
          if (!session()->get('is_logged_in')) {
            // Redirect pakai CodeIgniter-style agar tetap dalam flow framework
            redirect()->to('/auth/login')->send();
            exit;
        }
        $barangModel        = new BarangModel();
        $inventarisModel    = new InventarisModel();
        $userModel          = new UserModel();
        $peminjamanModel    = new PeminjamanModel();
        $pengembalianModel  = new PengembalianModel();
        $mutasiModel        = new MutasiModel();
        $logLoginModel      = new LogLoginModel();

        $data = [
            'jumlah_barang'     => $barangModel->countAllResults(),
            'jumlah_user'       => $userModel->countAllResults(),
            'jumlah_inventaris' => $inventarisModel->countAllResults(),

            'lastPeminjaman'    => $peminjamanModel->orderBy('tanggal_pinjam', 'DESC')->findAll(5),
            'lastPengembalian'  => $pengembalianModel->orderBy('tanggal_pengembalian', 'DESC')->findAll(5),
            'lastMutasi'        => $mutasiModel->orderBy('tanggal', 'DESC')->findAll(5),
            'lastLogLogin'      => $logLoginModel->orderBy('waktu_login', 'DESC')->findAll(5),

            'stat_peminjaman_bulanan' => $this->statistikPeminjamanBulanan(),
            'stat_mutasi'             => $this->statistikMutasiBulanan(),
        ];
dd(session()->get());

        return view('dashboard/index', $data);
    }

    private function statistikPeminjamanBulanan()
    {
        $db = \Config\Database::connect();
        return $db->query("
            SELECT MONTH(tanggal_pinjam) AS bulan, COUNT(*) AS jumlah
            FROM peminjaman
            GROUP BY MONTH(tanggal_pinjam)
        ")->getResultArray();
    }

    private function statistikMutasiBulanan()
    {
        $db = \Config\Database::connect();
        return $db->query("
            SELECT MONTH(tanggal) AS bulan, COUNT(*) AS jumlah
            FROM mutasi
            GROUP BY MONTH(tanggal)
        ")->getResultArray();
    }
}
