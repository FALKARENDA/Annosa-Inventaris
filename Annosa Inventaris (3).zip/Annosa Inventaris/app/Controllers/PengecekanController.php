<?php

namespace App\Controllers;

use App\Models\PengecekanModel;
use App\Models\InventarisModel;

class PengecekanController extends BaseController
{
    protected $pengecekanModel;
    protected $inventarisModel;

    public function __construct()
    {
        $this->pengecekanModel = new PengecekanModel();
        $this->inventarisModel = new InventarisModel();
    }

    public function index()
    {
        $data['pengecekan'] = $this->pengecekanModel->getWithInventaris();
        return view('pengecekan/index', $data);
    }

    public function create()
    {
        $data['inventaris'] = $this->inventarisModel->getWithRelations();
        return view('pengecekan/create', $data);
    }

    public function store()
    {
        $this->pengecekanModel->save([
            'inventaris_id'   => $this->request->getPost('inventaris_id'),
            'tanggal_cek'     => $this->request->getPost('tanggal_cek'),
            'kondisi_terkini' => $this->request->getPost('kondisi_terkini'),
            'petugas_cek'     => session()->get('username') ?? 'admin',
            'catatan'         => $this->request->getPost('catatan')
        ]);

        return redirect()->to('/pengecekan')->with('success', 'Data pengecekan berhasil ditambahkan');
    }

    public function edit($id)
    {
        $data['pengecekan'] = $this->pengecekanModel->find($id);
        $data['inventaris'] = $this->inventarisModel->getWithRelations();
        return view('pengecekan/edit', $data);
    }

    public function update($id)
    {
        $this->pengecekanModel->update($id, [
            'inventaris_id'   => $this->request->getPost('inventaris_id'),
            'tanggal_cek'     => $this->request->getPost('tanggal_cek'),
            'kondisi_terkini' => $this->request->getPost('kondisi_terkini'),
            'petugas_cek'     => session()->get('username') ?? 'admin',
            'catatan'         => $this->request->getPost('catatan')
        ]);

        return redirect()->to('/pengecekan')->with('success', 'Data pengecekan berhasil diperbarui');
    }

    public function delete($id)
    {
        $this->pengecekanModel->delete($id);
        return redirect()->to('/pengecekan')->with('success', 'Data pengecekan berhasil dihapus');
    }
}
