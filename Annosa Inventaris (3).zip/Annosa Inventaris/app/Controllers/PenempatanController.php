<?php

namespace App\Controllers;

use App\Models\PenempatanModel;
use App\Models\InventarisModel;
use App\Models\LokasiModel;

class PenempatanController extends BaseController
{
    protected $penempatanModel;
    protected $inventarisModel;
    protected $lokasiModel;

    public function __construct()
    {
        $this->penempatanModel = new PenempatanModel();
        $this->inventarisModel = new InventarisModel();
        $this->lokasiModel     = new LokasiModel();
    }

    public function index()
{
    $data['penempatan'] = $this->penempatanModel->getWithRelasi();
    $data['lokasi']     = $this->lokasiModel->findAll(); // ← WAJIB ADA
    $data['inventaris'] = $this->inventarisModel->getWithBarangLokasi(); // ← WAJIB ADA

    return view('penempatan/index', $data);
}


    public function create()
    {
        $data['inventaris'] = $this->inventarisModel->getWithBarangLokasi();
        $data['lokasi']     = $this->lokasiModel->findAll();
        return view('penempatan/create', $data);
    }

    public function store()
    {
        $this->penempatanModel->save([
            'inventaris_id'     => $this->request->getPost('inventaris_id'),
            'lokasi_id'         => $this->request->getPost('lokasi_id'),
            'tanggal'           => $this->request->getPost('tanggal'),
            'keterangan'        => $this->request->getPost('keterangan'),
            'tahun_anggaran'    => $this->request->getPost('tahun_anggaran'),
        ]);

        return redirect()->to('/penempatan')->with('success', 'Penempatan berhasil ditambahkan');
    }

   public function edit($id)
{
    $penempatan = $this->penempatanModel
        ->select('penempatan.*, barang.kode_barang, barang.model, barang.merk, lokasi.ruangan, lokasi.lantai, lokasi.gedung')
        ->join('inventaris', 'inventaris.id = penempatan.inventaris_id')
        ->join('barang', 'barang.id = inventaris.barang_id')
        ->join('lokasi', 'lokasi.id = penempatan.lokasi_id')
        ->where('penempatan.id', $id)
        ->first();

    if (!$penempatan) {
        throw new \CodeIgniter\Exceptions\PageNotFoundException("Data tidak ditemukan");
    }

    $lokasi = $this->lokasiModel->findAll();

    return view('penempatan/edit', [
        'penempatan' => $penempatan,
        'lokasi'     => $lokasi,
    ]);
}


    public function update($id)
    {
        $this->penempatanModel->update($id, [
            'inventaris_id'     => $this->request->getPost('inventaris_id'),
            'lokasi_id'         => $this->request->getPost('lokasi_id'),
            'tanggal'           => $this->request->getPost('tanggal'),
            'keterangan'        => $this->request->getPost('keterangan'),
            'tahun_anggaran'    => $this->request->getPost('tahun_anggaran'),
        ]);

        return redirect()->to('/penempatan')->with('success', 'Data penempatan berhasil diperbarui');
    }

    public function update_bulk()
{
    $data = $this->request->getPost('data');

    foreach ($data as $row) {
        if (!empty($row['id'])) {
            $this->penempatanModel->update($row['id'], [
                'tanggal'        => $row['tanggal'],
                'tahun_anggaran' => $row['tahun_anggaran'],
                'keterangan'     => $row['keterangan'],
            ]);
        }
    }

    return redirect()->to('/penempatan')->with('success', 'Semua perubahan berhasil disimpan.');
}

    public function delete($id)
    {
        $this->penempatanModel->delete($id);
        return redirect()->to('/penempatan')->with('success', 'Data penempatan berhasil dihapus');
    }
}
