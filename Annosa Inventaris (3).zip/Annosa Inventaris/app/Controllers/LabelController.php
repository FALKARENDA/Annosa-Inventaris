<?php

namespace App\Controllers;

use App\Models\InventarisModel;
use App\Models\LabelModel;
use CodeIgniter\Controller;

class LabelController extends Controller
{
    protected $inventarisModel;
    protected $labelModel;

    public function __construct()
    {
        $this->inventarisModel = new InventarisModel();
        $this->labelModel = new LabelModel();
    }

    public function index()
    {
        $data['inventaris'] = $this->inventarisModel->getWithBarangLokasi();
        return view('label/index', $data);
    }

    public function cetak($id)
    {
        $inventaris = $this->inventarisModel->getWithBarangLokasi($id);
        if (!$inventaris) {
            throw new \CodeIgniter\Exceptions\PageNotFoundException('Data tidak ditemukan');
        }

        // Simpan ke tabel label
        $this->labelModel->insert([
            'id_inventaris'    => $inventaris['id'],
            'nama_barang'      => $inventaris['tipe'],
            'kode_inventaris'  => $inventaris['kode_barang'],
            'kategori'         => $inventaris['tipe'],
            'lokasi'           => $inventaris['ruangan'],
            'tahun'            => $inventaris['tahun_anggaran'],
            'tgl_cetak'        => date('Y-m-d H:i:s')
        ]);

        return view('label/cetak', ['data' => $inventaris]);
    }
}
