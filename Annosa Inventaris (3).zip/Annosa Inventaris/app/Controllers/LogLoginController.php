<?php

namespace App\Controllers;

use App\Models\LogLoginModel;
use App\Models\UserModel;

class LogLoginController extends BaseController
{
    protected $logLoginModel;
    protected $userModel;

    public function __construct()
    {
        $this->logLoginModel = new LogLoginModel();
        $this->userModel     = new UserModel();
    }

    public function index()
    {
        $data['log'] = $this->logLoginModel
                            ->orderBy('waktu_login', 'DESC')
                            ->findAll();

        return view('log_login/index', $data);
    }

    // Optional: untuk menampilkan aktivitas berdasarkan jenis
    public function login()
    {
        $data['log'] = $this->logLoginModel->getRecentLogin(10);
        return view('log_login/login', $data);
    }

    public function logout()
    {
        $data['log'] = $this->logLoginModel->getRecentLogout(10);
        return view('log_login/logout', $data);
    }
}
