<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\NotifikasiModel;
use App\Models\BarangModel;

class NotifikasiController extends BaseController
{
    protected $notifikasiModel;
    protected $session;

    public function __construct()
    {
        $this->notifikasiModel = new NotifikasiModel();
        $this->session = session();
    }

    // ✅ Tampilkan semua notifikasi
    public function index()
    {
        $this->checkLogin();

        $status = $this->request->getGet('status');
        $cari   = $this->request->getGet('search');

        if ($status === 'belum') {
            $data['notifikasi'] = $this->notifikasiModel->getBelumDibaca();
        } elseif ($cari) {
            $data['notifikasi'] = $this->notifikasiModel->cariPesan($cari);
        } else {
            $data['notifikasi'] = $this->notifikasiModel->getAllWithBarang();
        }

        return view('notifikasi/index', $data);
    }

    // ✅ Tandai satu notifikasi sebagai sudah dibaca
    public function baca($id)
    {
        $this->checkLogin();
        $this->notifikasiModel->tandaiSudahDibaca($id);
        return redirect()->to('/notifikasi')->with('success', 'Notifikasi ditandai sudah dibaca.');
    }

    // ✅ Tandai semua sebagai sudah dibaca
    public function bacaSemua()
    {
        $this->checkLogin();
        $this->notifikasiModel->tandaiSemuaDibaca();
        return redirect()->to('/notifikasi')->with('success', 'Semua notifikasi ditandai sudah dibaca.');
    }

    // ✅ Tampilkan notifikasi terbaru
    public function terbaru()
    {
        $this->checkLogin();
        $data['notifikasi'] = $this->notifikasiModel->getTerbaru(10);
        return view('notifikasi/terbaru', $data);
    }

    // ✅ Notifikasi berdasarkan barang
    public function byBarang($kode_barang)
    {
        $this->checkLogin();
        $data['notifikasi'] = $this->notifikasiModel->getByBarang($kode_barang);
        return view('notifikasi/detail', $data);
    }

    // ✅ Filter berdasarkan tanggal
    public function byTanggal()
    {
        $this->checkLogin();

        $tanggal = $this->request->getGet('tanggal');
        $data['notifikasi'] = $tanggal
            ? $this->notifikasiModel->getByTanggal($tanggal)
            : [];

        return view('notifikasi/tanggal', $data);
    }

    // ✅ Proteksi login
    private function checkLogin()
    {
        if (!$this->session->get('is_logged_in')) {
            return redirect()->to('/login')->send();
        }
    }
}
