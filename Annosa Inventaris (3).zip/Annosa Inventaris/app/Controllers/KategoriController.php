<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\KategoriModel;

class KategoriController extends BaseController
{
    protected $kategoriModel;
    protected $session;
    protected $validation;

    public function __construct()
    {
        $this->kategoriModel = new KategoriModel();
        $this->session = session();
        $this->validation = \Config\Services::validation();
    }

public function index()
{
    $this->checkLogin();
    $q = $this->request->getGet('q');

    $kategori = $this->kategoriModel
        ->select('kategori.*, COUNT(barang.kode_barang) AS total_barang')
        ->join('barang', 'barang.kategori_id = kategori.id', 'left')
        ->groupBy('kategori.id')
        ->orderBy('nama_kategori', 'ASC');

    if ($q) {
        $kategori->like('kategori.nama_kategori', $q);
    }

    $data['kategori'] = $kategori->paginate(10);
    $data['pager'] = $this->kategoriModel->pager;

    return view('kategori/index', $data);
}


    public function create()
    {
        $this->checkLogin();
        return view('kategori/create');
    }

    public function store()
    {
        $this->checkLogin();

        $rules = [
            'nama_kategori' => 'required|min_length[3]',
        ];

        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('error', $this->validator->getErrors()['nama_kategori']);
        }

        $this->kategoriModel->insert([
            'nama_kategori' => $this->request->getPost('nama_kategori'),
            'keterangan'    => $this->request->getPost('keterangan'),
        ]);

        return redirect()->to('/kategori')->with('success', 'Kategori berhasil ditambahkan.');
    }

    public function edit($id)
    {
        $this->checkLogin();

        $kategori = $this->kategoriModel->find($id);

        if (!$kategori) {
            throw new \CodeIgniter\Exceptions\PageNotFoundException("Kategori tidak ditemukan.");
        }

        return view('kategori/edit', ['kategori' => $kategori]);
    }

    public function update($id)
    {
        $this->checkLogin();

        $rules = [
            'nama_kategori' => 'required|min_length[3]',
        ];

        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('error', $this->validator->getErrors()['nama_kategori']);
        }

        $this->kategoriModel->update($id, [
            'nama_kategori' => $this->request->getPost('nama_kategori'),
            'keterangan'    => $this->request->getPost('keterangan'),
        ]);

        return redirect()->to('/kategori')->with('success', 'Kategori berhasil diperbarui.');
    }

    public function delete($id)
    {
        $this->checkLogin();

        $this->kategoriModel->delete($id);
        return redirect()->to('/kategori')->with('success', 'Kategori berhasil dihapus.');
    }

    private function checkLogin()
    {
        if (!$this->session->get('is_logged_in')) {
            return redirect()->to('/login')->send();
        }
    }

    // Optional: Export Excel
    public function export()
    {
        $this->checkLogin();

        $data = $this->kategoriModel->orderBy('nama_kategori', 'ASC')->findAll();

        header("Content-type: application/vnd.ms-excel");
        header("Content-Disposition: attachment; filename=kategori_" . date('Ymd') . ".xls");

        echo "<table border='1'>";
        echo "<tr><th>ID</th><th>Nama Kategori</th><th>Keterangan</th></tr>";
        foreach ($data as $row) {
            echo "<tr>
                    <td>{$row['id']}</td>
                    <td>{$row['nama_kategori']}</td>
                    <td>{$row['keterangan']}</td>
                  </tr>";
        }
        echo "</table>";
        exit;
    }
}
