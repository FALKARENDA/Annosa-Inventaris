<?php

namespace App\Controllers;

use App\Models\InventarisModel;
use App\Models\BarangModel;
use App\Models\LokasiModel;

class InventarisController extends BaseController
{
    protected $inventarisModel;
    protected $barangModel;
    protected $lokasiModel;

    public function __construct()
    {
        $this->inventarisModel = new InventarisModel();
        $this->barangModel = new BarangModel();
        $this->lokasiModel = new LokasiModel();
    }

    public function index()
    {
        $data['inventaris'] = $this->inventarisModel->getWithBarangLokasi();
        return view('inventaris/index', $data);
    }

    public function create()
    {
        $data['barang'] = $this->barangModel->findAll();
        $data['lokasi'] = $this->lokasiModel->findAll();
        return view('inventaris/create', $data);
    }

    public function store()
    {
        $this->inventarisModel->save([
            'barang_id'      => $this->request->getPost('barang_id'),
            'lokasi_id'      => $this->request->getPost('lokasi_id'),
            'kondisi'        => $this->request->getPost('kondisi'),
            'jumlah'         => $this->request->getPost('jumlah'),
            'tanggal_masuk'  => $this->request->getPost('tanggal_masuk'),
            'sumber_dana'    => $this->request->getPost('sumber_dana'),
            'tahun_anggaran' => $this->request->getPost('tahun_anggaran'),
            'keterangan'     => $this->request->getPost('keterangan')
        ]);

        return redirect()->to('/inventaris');
    }

    public function edit($id)
    {
        $data['inventaris'] = $this->inventarisModel->getWithBarangLokasi($id);
        $data['barang'] = $this->barangModel->findAll();
        $data['lokasi'] = $this->lokasiModel->findAll();
        return view('inventaris/edit', $data);
    }

    public function update($id)
    {
        $this->inventarisModel->update($id, [
            'barang_id'      => $this->request->getPost('barang_id'),
            'lokasi_id'      => $this->request->getPost('lokasi_id'),
            'kondisi'        => $this->request->getPost('kondisi'),
            'jumlah'         => $this->request->getPost('jumlah'),
            'tanggal_masuk'  => $this->request->getPost('tanggal_masuk'),
            'sumber_dana'    => $this->request->getPost('sumber_dana'),
            'tahun_anggaran' => $this->request->getPost('tahun_anggaran'),
            'keterangan'     => $this->request->getPost('keterangan')
        ]);

        return redirect()->to('/inventaris');
    }

    public function delete($id)
    {
        $this->inventarisModel->delete($id);
        return redirect()->to('/inventaris');
    }
}
