namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\UserModel;

class LaporanController extends BaseController
{
    public function pengguna()
    {
        $userModel = new UserModel();

        $q = $this->request->getGet('q');
        $role = $this->request->getGet('role');

        $builder = $userModel;

        if ($q) {
            $builder = $builder->groupStart()
                ->like('nama', $q)
                ->orLike('email', $q)
                ->groupEnd();
        }

        if ($role) {
            $builder = $builder->where('role', $role);
        }

        $data['users'] = $builder->orderBy('created_at', 'DESC')->paginate(10);
        $data['pager'] = $userModel->pager;

        return view('laporan/pengguna', $data);
    }
}
namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\UserModel;

class LaporanController extends BaseController
{
    public function pengguna()
    {
        $userModel = new UserModel();

        $q = $this->request->getGet('q');
        $role = $this->request->getGet('role');

        $builder = $userModel;

        if ($q) {
            $builder = $builder->groupStart()
                ->like('nama', $q)
                ->orLike('email', $q)
                ->groupEnd();
        }

        if ($role) {
            $builder = $builder->where('role', $role);
        }

        $data['users'] = $builder->orderBy('created_at', 'DESC')->paginate(10);
        $data['pager'] = $userModel->pager;

        return view('laporan/pengguna', $data);
    }
}
