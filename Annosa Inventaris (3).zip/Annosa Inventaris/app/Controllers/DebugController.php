<?php

namespace App\Controllers;

class DebugController extends \CodeIgniter\Controller
{
    public function index()
    {
        $password = 'MASUKKAN_PASSWORD_YANG_KAMU TES';
        $hash = '$2y$10$DtGm5TKB4TzEpilS1A.jV.22Larj8IycL.gOjIWUsmdF5VLsBqft.';

        if (password_verify($password, $hash)) {
            echo "✅ PASSWORD BENAR";
        } else {
            echo "❌ PASSWORD SALAH";
        }
    }
}
