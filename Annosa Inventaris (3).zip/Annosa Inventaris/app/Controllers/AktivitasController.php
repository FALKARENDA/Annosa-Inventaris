<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\AktivitasModel;
use App\Models\BarangModel;
use App\Models\UserModel;

class AktivitasController extends BaseController
{
    protected $aktivitasModel;
    protected $session;

    public function __construct()
    {
        $this->aktivitasModel = new AktivitasModel();
        $this->session = session();
    }

    // ✅ Lihat semua aktivitas
    public function index()
    {
        $this->checkLogin();

        $jenis = $this->request->getGet('jenis');
        $cari = $this->request->getGet('search');

        if ($jenis) {
            $data['aktivitas'] = $this->aktivitasModel->getByJenis($jenis);
        } elseif ($cari) {
            $data['aktivitas'] = $this->aktivitasModel->getByPetugasNama($cari);
        } else {
            $data['aktivitas'] = $this->aktivitasModel->getAllAktivitasFull();
        }

        return view('aktivitas/index', $data);
    }

    // ✅ Form tambah aktivitas
    public function create()
    {
        $this->checkLogin();

        $data['barang'] = (new BarangModel())->findAll();
        return view('aktivitas/create', $data);
    }

    // ✅ Simpan aktivitas
    public function store()
    {
        $this->checkLogin();

        $data = $this->request->getPost();
        $data['petugas'] = $this->session->get('id_user');

        $this->aktivitasModel->insert($data);
        return redirect()->to('/aktivitas')->with('success', 'Aktivitas berhasil ditambahkan.');
    }

    // ✅ Form edit
    public function edit($id)
    {
        $this->checkLogin();

        $data['aktivitas'] = $this->aktivitasModel->find($id);
        $data['barang'] = (new BarangModel())->findAll();

        if (!$data['aktivitas']) {
            throw new \CodeIgniter\Exceptions\PageNotFoundException("Aktivitas tidak ditemukan");
        }

        return view('aktivitas/edit', $data);
    }

    // ✅ Simpan update aktivitas
    public function update($id)
    {
        $this->checkLogin();

        $data = $this->request->getPost();
        $this->aktivitasModel->update($id, $data);

        return redirect()->to('/aktivitas')->with('success', 'Aktivitas berhasil diperbarui.');
    }

    // ✅ Hapus aktivitas
    public function delete($id)
    {
        $this->checkLogin();
        $this->aktivitasModel->delete($id);
        return redirect()->to('/aktivitas')->with('success', 'Aktivitas berhasil dihapus.');
    }

    // ✅ Detail aktivitas berdasarkan barang
    public function detailByBarang($kode_barang)
    {
        $this->checkLogin();

        $data['aktivitas'] = $this->aktivitasModel->getAktivitasByBarang($kode_barang);
        $data['barang'] = (new BarangModel())->find($kode_barang);

        return view('aktivitas/detail', $data);
    }

    // ✅ Proteksi login
    private function checkLogin()
    {
        if (!$this->session->get('is_logged_in')) {
            return redirect()->to('/login')->send();
        }
    }
}
