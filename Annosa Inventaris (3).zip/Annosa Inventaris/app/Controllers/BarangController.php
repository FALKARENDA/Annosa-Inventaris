<?php

namespace App\Controllers;

use App\Models\BarangModel;
use CodeIgniter\Controller;

class BarangController extends Controller
{
    protected $barangModel;

    public function __construct()
    {
        $this->barangModel = new BarangModel();
    }
public function index()
{
    $data['items'] = $this->barangModel->findAll();
    return view('barang/index', $data);
}

    public function create()
    {
        return view('barang/create');
    }

    public function store()
    {
        $file = $this->request->getFile('foto');
        $fileName = null;

        if ($file && $file->isValid() && !$file->hasMoved()) {
            $fileName = $file->getRandomName();
            $file->move('uploads/', $fileName);
        }

        $this->barangModel->insert([
            'nama_barang' => $this->request->getPost('nama_barang'),
            'kode_barang' => $this->request->getPost('kode_barang'),
            'merk'        => $this->request->getPost('merk'),
            'model'       => $this->request->getPost('model'),
            'warna'       => $this->request->getPost('warna'),
            'spesifikasi' => $this->request->getPost('spesifikasi'),
            'foto'        => $fileName,
        ]);

        return redirect()->to('/barang')->with('success', 'Data berhasil ditambahkan.');
    }

    public function edit($id)
    {
        $barang = $this->barangModel->find($id);
        if (!$barang) {
            return redirect()->to('/barang')->with('error', 'Data tidak ditemukan.');
        }

        return view('barang/edit', ['barang' => $barang]);
    }

    public function update($id)
    {
        $barang = $this->barangModel->find($id);
        if (!$barang) {
            return redirect()->to('/barang')->with('error', 'Data tidak ditemukan.');
        }

        $file = $this->request->getFile('foto');
        $fileName = $barang['foto'];

        if ($file && $file->isValid() && !$file->hasMoved()) {
            $fileName = $file->getRandomName();
            $file->move('uploads/', $fileName);

            if (!empty($barang['foto']) && file_exists('uploads/' . $barang['foto'])) {
                unlink('uploads/' . $barang['foto']);
            }
        }

        $this->barangModel->update($id, [
            'nama_barang' => $this->request->getPost('nama_barang'),
            'kode_barang' => $this->request->getPost('kode_barang'),
            'merk'        => $this->request->getPost('merk'),
            'model'       => $this->request->getPost('model'),
            'warna'       => $this->request->getPost('warna'),
            'spesifikasi' => $this->request->getPost('spesifikasi'),
            'foto'        => $fileName,
        ]);

        return redirect()->to('/barang')->with('success', 'Data berhasil diperbarui.');
    }

    public function update_bulk()
{
    $items = $this->request->getPost('items');

    if ($items && is_array($items)) {
        foreach ($items as $id => $data) {
            $this->barangModel->update($id, $data);
        }
        return redirect()->to('/barang')->with('success', 'Perubahan berhasil disimpan.');
    }

    return redirect()->to('/barang')->with('error', 'Tidak ada data untuk disimpan.');
}

    public function delete($id)
    {
        $barang = $this->barangModel->find($id);
        if (!$barang) {
            return redirect()->to('/barang')->with('error', 'Data tidak ditemukan.');
        }

        if (!empty($barang['foto']) && file_exists('uploads/' . $barang['foto'])) {
            unlink('uploads/' . $barang['foto']);
        }

        $this->barangModel->delete($id);
        return redirect()->to('/barang')->with('success', 'Data berhasil dihapus.');
    }

    public function detail($id)
    {
        $barang = $this->barangModel->find($id);
        if (!$barang) {
            return redirect()->to('/barang')->with('error', 'Data tidak ditemukan.');
        }

        return view('barang/detail', ['barang' => $barang]);
    }

    public function search()
    {
        $keyword = $this->request->getGet('keyword');
        $data['barang'] = $this->barangModel->search($keyword);
        return view('barang/index', $data);
    }
}
