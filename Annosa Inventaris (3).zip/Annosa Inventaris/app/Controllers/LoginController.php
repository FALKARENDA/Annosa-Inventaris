<?php

namespace App\Controllers;

use App\Models\UserModel;
use CodeIgniter\Controller;

class LoginController extends Controller
{
    protected $userModel;
    protected $session;
    protected $validation;

    public function __construct()
    {
        $this->userModel = new UserModel();
        $this->session = session();
        $this->validation = \Config\Services::validation();
    }

    // ✅ Form Login
    public function index()
    {
        if ($this->session->get('is_logged_in')) {
            return redirect()->to('/dashboard');
        }

        return view('auth/login');
    }

    // ✅ Proses Login
    public function login()
    {
        $username = trim($this->request->getPost('username'));
        $password = trim($this->request->getPost('password'));
        $remember = $this->request->getPost('remember');

        $users = $this->userModel->where('username', $username)->findAll();

        if (count($users) > 1) {
            return redirect()->back()->withInput()->with('error', 'Terjadi duplikat user. Hubungi admin.');
        } elseif (count($users) === 0) {
            return redirect()->back()->withInput()->with('error', 'Username tidak ditemukan.');
        }

        $user = $users[0];

        if (!isset($user['password']) || !password_verify($password, $user['password'])) {
            return redirect()->back()->withInput()->with('error', 'Password salah.');
        }

        if ($user['status'] !== 'Aktif') {
            return redirect()->back()->withInput()->with('error', 'Akun Anda tidak aktif.');
        }

        // Set session login
        $this->session->set([
            'id' => $user['id'],
            'username' => $user['username'],
            'level' => $user['level'],
            'status' => $user['status'],
            'is_logged_in' => true
        ]);

        // Remember me
        if ($remember) {
            setcookie('remember_username', $username, time() + (86400 * 30), "/");
        } else {
            setcookie('remember_username', '', time() - 3600, "/");
        }

        return redirect()->to('/dashboard');
    }

    // ✅ Lupa Password
    public function forgot()
    {
        if ($this->request->getMethod() === 'get') {
            return view('auth/forgot');
        }

        $username = $this->request->getPost('username');
        $pin = $this->request->getPost('pin');

        $user = $this->userModel->where('username', $username)->first();

        if (!$user) {
            return redirect()->back()->with('error', 'Username tidak ditemukan.');
        }

        if ($pin !== '1234') {
            return redirect()->back()->with('error', 'PIN tidak valid.');
        }

        $newPassword = 'admin123';
        $hash = password_hash($newPassword, PASSWORD_DEFAULT);

        $this->userModel->update($user['id'], ['password' => $hash]);

        return redirect()->to('/login')->with('success', 'Password berhasil direset ke: <b>' . $newPassword . '</b>');
    }

    // ✅ Login dengan PIN
    public function loginPin()
    {
        if ($this->request->getMethod() === 'get') {
            return view('auth/login_pin');
        }

        $username = $this->request->getPost('username');
        $pin = $this->request->getPost('pin');

        if ($pin !== '1234') {
            return redirect()->back()->with('error', 'PIN salah!');
        }

        $user = $this->userModel->where('username', $username)->first();

        if (!$user) {
            return redirect()->back()->with('error', 'User tidak ditemukan!');
        }

        $this->session->set([
            'id' => $user['id'],
            'username' => $user['username'],
            'level' => $user['level'],
            'status' => $user['status'],
            'is_logged_in' => true
        ]);

        return redirect()->to('/dashboard');
    }

    // ✅ Form Register
    public function registerForm()
    {
        return view('auth/register');
    }

    // ✅ Proses Register
    public function register()
    {
        $rules = [
            'username' => 'required|is_unique[user.username]',
            'password' => 'required|min_length[5]',
        ];

        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        $data = [
            'username' => trim($this->request->getPost('username')),
            'password' => password_hash($this->request->getPost('password'), PASSWORD_DEFAULT),
            'level'    => 'User',
            'status'   => 'Aktif'
        ];

        $this->userModel->insert($data);

        return redirect()->to('/auth/login')->with('success', 'Registrasi berhasil! Silakan login.');
    }

    // ✅ Logout
   public function logout()
{
    // Hapus cookie remember
    setcookie('remember_username', '', time() - 3600, "/");

    // Hancurkan session
    $this->session->destroy();

    return redirect()->to('/auth/login')->with('success', 'Berhasil logout.');
}

}
