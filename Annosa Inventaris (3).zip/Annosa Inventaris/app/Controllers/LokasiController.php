<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\LokasiModel;

class LokasiController extends BaseController
{
    protected $lokasiModel;

    public function __construct()
    {
        $this->lokasiModel = new LokasiModel();
    }

    // ✅ Tampilkan daftar lokasi
    public function index()
    {
        $data['lokasi'] = $this->lokasiModel->findAll();
        return view('lokasi/index', $data);
    }

    // ✅ Form tambah lokasi
    public function create()
    {
        return view('lokasi/create');
    }

    // ✅ Simpan data lokasi
    public function store()
    {
        $data = $this->request->getPost();
        $this->lokasiModel->insert($data);
        return redirect()->to('/lokasi')->with('success', 'Lokasi berhasil ditambahkan.');
    }

    // ✅ Form edit lokasi
    public function edit($id)
    {
        $data['lokasi'] = $this->lokasiModel->find($id);
        return view('lokasi/edit', $data);
    }

    // ✅ Simpan update lokasi
    public function update($id)
    {
        $data = $this->request->getPost();
        $this->lokasiModel->update($id, $data);
        return redirect()->to('/lokasi')->with('success', 'Lokasi berhasil diperbarui.');
    }

    // ✅ Hapus lokasi
    public function delete($id)
    {
        $this->lokasiModel->delete($id);
        return redirect()->to('/lokasi')->with('success', 'Lokasi berhasil dihapus.');
    }
}
