<?php

namespace App\Controllers\Api;

use CodeIgniter\RESTful\ResourceController;
use App\Models\NotifikasiModel;

class NotifikasiApi extends ResourceController
{
    public function terbaru()
    {
        $model = new NotifikasiModel();
        $notifikasi = $model->getTerbaru(5);

        return $this->response->setJSON($notifikasi);
    }
}
