<?php

namespace App\Controllers;

use App\Models\UserModel;

class UserController extends BaseController
{
    protected $userModel;

    public function __construct()
    {
        $this->userModel = new UserModel();
    }

    public function index()
    {
        $data['users'] = $this->userModel->findAll();
        return view('user/index', $data);
    }

    public function create()
    {
        return view('user/create');
    }

  public function store()
{
    $data = [
        'username' => $this->request->getPost('username'),
        'password' => $this->request->getPost('password'),
        'level'    => $this->request->getPost('level'),
        'status'   => $this->request->getPost('status'),
    ];

    if (empty($data['level']) || empty($data['status'])) {
        return redirect()->back()->withInput()->with('error', 'Level dan status wajib diisi.');
    }

    $this->userModel->save($data);

    return redirect()->to('/user')->with('success', 'User berhasil ditambahkan');
}



    public function edit($id)
    {
        $data['user'] = $this->userModel->find($id);
        return view('user/edit', $data);
    }

    public function update($id)
    {
        $this->userModel->update($id, [
            'username' => $this->request->getPost('username'),
            'password' => $this->request->getPost('password'), // kosong = tidak ubah
            'level'    => $this->request->getPost('level'),
            'status'   => $this->request->getPost('status'),
        ]);

        return redirect()->to('/user')->with('success', 'User berhasil diperbarui');
    }

    public function delete($id)
    {
        $this->userModel->delete($id);
        return redirect()->to('/user')->with('success', 'User berhasil dihapus');
    }
}
