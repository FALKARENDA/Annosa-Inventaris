<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\UserModel;

class ForgotController extends BaseController
{
    protected $userModel;

    public function __construct()
    {
        $this->userModel = new UserModel();
    }

    // ✅ Tampilkan form lupa password
    public function index()
    {
        return view('auth/forgot');
    }

    // ✅ Proses reset password dengan PIN
    public function reset()
    {
        $username = trim($this->request->getPost('username'));
        $pin      = $this->request->getPost('pin');

        // Validasi awal
        if (!$username || !$pin) {
            return redirect()->back()->withInput()->with('error', 'Silakan isi semua kolom.');
        }

        // Ambil user berdasarkan username
        $user = $this->userModel
            ->where('username', $username)
            ->first();

        if (!$user) {
            // 🔍 DEBUG jika perlu
            // log_message('debug', 'Username input: ' . $username);
            // log_message('debug', 'All users: ' . json_encode($this->userModel->findAll()));

            return redirect()->back()->withInput()->with('error', 'Username tidak ditemukan.');
        }

        // Validasi PIN (sementara default '1234')
        if ($pin !== '1234') {
            return redirect()->back()->withInput()->with('error', 'PIN salah.');
        }

        // Generate password baru
        $newPassword = 'admin123'; // Atau random jika mau
        $hash        = password_hash($newPassword, PASSWORD_DEFAULT);

        // Update password
        $this->userModel->update($user['id'], ['password' => $hash]);

        return redirect()->to('/auth/login')->with('success', 'Password berhasil direset ke: <b>' . $newPassword . '</b>');
    }
}
