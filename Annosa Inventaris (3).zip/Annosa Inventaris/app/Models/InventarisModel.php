<?php

namespace App\Models;

use CodeIgniter\Model;

class InventarisModel extends Model
{
    protected $table = 'inventaris';
    protected $primaryKey = 'id';
    protected $allowedFields = [
        'barang_id',
        'lokasi_id',
        'kondisi',
        'jumlah',
        'tanggal_masuk',
        'sumber_dana',
        'tahun_anggaran',
        'keterangan'
    ];

    public function getWithBarangLokasi($id = null)
{
    $builder = $this->db->table($this->table)
        ->select('inventaris.*, 
                  barang.kode_barang, 
                  barang.nama_barang AS tipe, 
                  barang.merk, 
                  barang.model, 
                  barang.warna,
                  lokasi.ruangan, 
                  lokasi.lantai, 
                  lokasi.gedung')
        ->join('barang', 'barang.id = inventaris.barang_id', 'left')
        ->join('lokasi', 'lokasi.id = inventaris.lokasi_id', 'left');

    if ($id !== null) {
        return $builder->where('inventaris.id', $id)->get()->getRowArray();
    }

    return $builder->get()->getResultArray();
}


        
}
