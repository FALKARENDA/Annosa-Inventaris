<?php

namespace App\Models;

use CodeIgniter\Model;

class PeminjamanModel extends Model
{
    protected $table            = 'peminjaman';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';

    protected $allowedFields = [
        'kode_peminjaman',
        'nama_peminjam',
        'nomor_identitas',
        'tanggal_pinjam',
        'tanggal_kembali',
        'inventaris_id',
        'jumlah',
        'keperluan',
        'status',
        'petugas_input',
        'verifikasi'
    ];

    public function getWithInventaris()
    {
        return $this->select('peminjaman.*, inventaris.id AS inventaris_nomor, barang.nama_barang')
                    ->join('inventaris', 'inventaris.id = peminjaman.inventaris_id', 'left')
                    ->join('barang', 'barang.id = inventaris.barang_id', 'left')
                    ->orderBy('peminjaman.tanggal_pinjam', 'DESC')
                    ->findAll();
    }
}
