<?php

namespace App\Models;

use CodeIgniter\Model;

class DokumenModel extends Model
{
    protected $table = 'dokumen_barang';
    protected $primaryKey = 'id_dokumen';
    protected $useAutoIncrement = true;
    protected $allowedFields = [
        'kode_barang', 'tipe_dokumen', 'url_file', 'tgl_upload'
    ];
    protected $useTimestamps = false;
    protected $returnType = 'array';

    // ✅ Ambil semua dokumen milik 1 barang
    public function getDokumenByBarang($kode_barang)
    {
        return $this->where('kode_barang', $kode_barang)->findAll();
    }

    // ✅ Ambil dokumen + nama barang
    public function getAllWithBarang()
    {
        return $this->select('dokumen_barang.*, barang.nama_barang')
                    ->join('barang', 'barang.kode_barang = dokumen_barang.kode_barang')
                    ->orderBy('tgl_upload', 'DESC')
                    ->findAll();
    }

    // ✅ Filter berdasarkan tipe dokumen (nota, surat, dll)
    public function getByTipe($tipe)
    {
        return $this->where('tipe_dokumen', $tipe)->findAll();
    }

    // ✅ Filter berdasarkan tanggal upload
    public function getByTanggalUpload($tanggal)
    {
        return $this->where('tgl_upload', $tanggal)->findAll();
    }

    // ✅ Cari dokumen berdasarkan nama barang
    public function cariByNamaBarang($nama)
    {
        return $this->select('dokumen_barang.*, barang.nama_barang')
                    ->join('barang', 'barang.kode_barang = dokumen_barang.kode_barang')
                    ->like('barang.nama_barang', $nama)
                    ->findAll();
    }

    // ✅ Ambil dokumen terbaru
    public function getDokumenTerbaru()
    {
        return $this->orderBy('tgl_upload', 'DESC')->first();
    }

    // ✅ Hitung jumlah dokumen per barang
    public function countDokumenPerBarang($kode_barang)
    {
        return $this->where('kode_barang', $kode_barang)->countAllResults();
    }

    // ✅ Statistik dokumen per tipe (buat chart/pie)
    public function countByTipe()
    {
        return $this->select('tipe_dokumen, COUNT(*) as total')
                    ->groupBy('tipe_dokumen')
                    ->findAll();
    }
}
