<?php

namespace App\Models;

use CodeIgniter\Model;

class PengembalianModel extends Model
{
    protected $table            = 'pengembalian';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';

    protected $allowedFields = [
        'kode_pengembalian',
        'peminjaman_id',
        'tanggal_pengembalian',
        'jumlah_kembali',
        'kondisi_kembali',
        'catatan_kembali',
        'status',
        'petugas_terima',
        'verifikasi'
    ];

    public function getWithPeminjaman()
    {
        return $this->select('pengembalian.*, peminjaman.kode_peminjaman, peminjaman.nama_peminjam')
                    ->join('peminjaman', 'peminjaman.id = pengembalian.peminjaman_id', 'left')
                    ->orderBy('tanggal_pengembalian', 'DESC')
                    ->findAll();
    }
}
