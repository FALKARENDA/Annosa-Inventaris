<?php

namespace App\Models;

use CodeIgniter\Model;

class LabelModel extends Model
{
    protected $table = 'label';
    protected $primaryKey = 'id';
    protected $allowedFields = [
        'id_inventaris',
        'nama_barang',
        'kode_inventaris',
        'kategori',
        'lokasi',
        'tahun',
        'tgl_cetak'
    ];
    public $useTimestamps = false;
}
