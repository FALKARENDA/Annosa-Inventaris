<?php

namespace App\Models;

use CodeIgniter\Model;

class BarangModel extends Model
{
    protected $table            = 'barang';
    protected $primaryKey       = 'id';
    protected $allowedFields    = [
        'nama_barang',
        'kode_barang',
        'merk',
        'model',
        'warna',
        'spesifikasi',
        'foto',
    ];
    protected $useTimestamps = false;

    // 🔍 Fungsi pencarian
    public function search($keyword)
    {
        return $this->like('nama_barang', $keyword)
                    ->orLike('kode_barang', $keyword)
                    ->orLike('merk', $keyword)
                    ->orLike('model', $keyword)
                    ->orLike('warna', $keyword)
                    ->findAll();
    }
}
