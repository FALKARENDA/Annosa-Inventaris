<?php

namespace App\Models;

use CodeIgniter\Model;

class AktivitasModel extends Model
{
    protected $table = 'aktivitas_barang';
    protected $primaryKey = 'id_aktivitas';
    protected $useAutoIncrement = true;
    protected $allowedFields = [
        'kode_barang', 'jenis_aktivitas', 'tgl_aktivitas', 'deskripsi',
        'metode_pengemasan', 'bahan_pengemas', 'tujuan_penitipan', 'petugas'
    ];
    protected $useTimestamps = false;
    protected $returnType = 'array';

    // ✅ Ambil aktivitas berdasarkan barang
    public function getAktivitasByBarang($kode_barang)
    {
        return $this->where('kode_barang', $kode_barang)->findAll();
    }

    // ✅ Ambil aktivitas + nama petugas
    public function getAktivitasWithPetugas()
    {
        return $this->select('aktivitas_barang.*, user.nama_lengkap')
                    ->join('user', 'user.id_user = aktivitas_barang.petugas')
                    ->orderBy('tgl_aktivitas', 'DESC')
                    ->findAll();
    }

    // ✅ Ambil aktivitas + nama barang + petugas
    public function getAllAktivitasFull()
    {
        return $this->select('aktivitas_barang.*, user.nama_lengkap, barang.nama_barang')
                    ->join('user', 'user.id_user = aktivitas_barang.petugas')
                    ->join('barang', 'barang.kode_barang = aktivitas_barang.kode_barang')
                    ->orderBy('tgl_aktivitas', 'DESC')
                    ->findAll();
    }

    // ✅ Filter berdasarkan jenis aktivitas (penitipan, penjualan, dll)
    public function getByJenis($jenis)
    {
        return $this->where('jenis_aktivitas', $jenis)->findAll();
    }

    // ✅ Statistik aktivitas (untuk chart pie/batang)
    public function countByJenisAktivitas()
    {
        return $this->select('jenis_aktivitas, COUNT(*) as total')
                    ->groupBy('jenis_aktivitas')
                    ->findAll();
    }

    // ✅ Cari aktivitas berdasarkan tanggal
    public function getByTanggal($tanggal)
    {
        return $this->where('tgl_aktivitas', $tanggal)->findAll();
    }

    // ✅ Cari aktivitas berdasarkan nama petugas
    public function getByPetugasNama($nama)
    {
        return $this->select('aktivitas_barang.*, user.nama_lengkap')
                    ->join('user', 'user.id_user = aktivitas_barang.petugas')
                    ->like('user.nama_lengkap', $nama)
                    ->findAll();
    }

    // ✅ Notifikasi dinamis: penitipan lebih dari N hari
    public function getNotifikasiPenitipanLama($hari = 7)
    {
        return $this->where('jenis_aktivitas', 'penitipan')
                    ->where('DATEDIFF(CURDATE(), tgl_aktivitas) >', $hari)
                    ->findAll();
    }

    // ✅ Ambil aktivitas terakhir untuk 1 barang
    public function getAktivitasTerakhir($kode_barang)
    {
        return $this->where('kode_barang', $kode_barang)
                    ->orderBy('tgl_aktivitas', 'DESC')
                    ->first();
    }
}
