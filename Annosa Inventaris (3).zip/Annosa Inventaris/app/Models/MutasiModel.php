<?php

namespace App\Models;

use CodeIgniter\Model;

class MutasiModel extends Model
{
    protected $table = 'mutasi';
    protected $primaryKey = 'id';
    protected $useAutoIncrement = true;
    protected $returnType = 'array';

    protected $allowedFields = [
        'inventaris_id',
        'tanggal',
        'lokasi_awal_id',
        'lokasi_tujuan_id',
        'tahun_anggaran',
        'keterangan'
    ];

    public function getWithRelasi()
    {
        return $this->select('mutasi.*, 
                              b.kode_barang,
                              b.nama_barang AS tipe,
                              b.merk, 
                              b.model, 
                              b.warna,
                              asal.ruangan AS lokasi_awal, 
                              tujuan.ruangan AS lokasi_tujuan')
                    ->join('inventaris inv', 'inv.id = mutasi.inventaris_id', 'left')
                    ->join('barang b', 'b.id = inv.barang_id', 'left')
                    ->join('lokasi asal', 'asal.id = mutasi.lokasi_awal_id', 'left')
                    ->join('lokasi tujuan', 'tujuan.id = mutasi.lokasi_tujuan_id', 'left')
                    ->orderBy('mutasi.tanggal', 'DESC')
                    ->findAll();
    }
}
