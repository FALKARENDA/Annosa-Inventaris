<?php

namespace App\Models;

use CodeIgniter\Model;

class NotifikasiModel extends Model
{
    protected $table = 'notifikasi';
    protected $primaryKey = 'id';
    protected $useAutoIncrement = true;
    protected $allowedFields = [
        'kode_barang', 'pesan', 'tgl_aktivitas', 'is_read'
    ];
    protected $useTimestamps = false;
    protected $returnType = 'array';

    // ✅ Ambil semua notifikasi + nama barang
    public function getAllWithBarang()
    {
        return $this->select('notifikasi.*, barang.nama_barang')
                    ->join('barang', 'barang.kode_barang = notifikasi.kode_barang', 'left')
                    ->orderBy('tgl_aktivitas', 'DESC')
                    ->findAll();
    }

    // ✅ Ambil notifikasi berdasarkan barang
    public function getByBarang($kode_barang)
    {
        return $this->where('kode_barang', $kode_barang)
                    ->orderBy('tgl_aktivitas', 'DESC')
                    ->findAll();
    }

    // ✅ Ambil notifikasi yang belum dibaca untuk barang tertentu
    public function getBelumDibaca($kode_barang = null)
    {
        $this->where('is_read', 0);
        if ($kode_barang) {
            $this->where('kode_barang', $kode_barang);
        }
        return $this->orderBy('tgl_aktivitas', 'DESC')->findAll();
    }

    // ✅ Tandai 1 notifikasi sudah dibaca
    public function tandaiSudahDibaca($id)
    {
        return $this->update($id, ['is_read' => 1]);
    }

    // ✅ Tandai semua notifikasi sebagai sudah dibaca
    public function tandaiSemuaDibaca()
    {
        return $this->where('is_read', 0)->set(['is_read' => 1])->update();
    }

    // ✅ Ambil notifikasi terbaru
    public function getTerbaru($limit = 5)
    {
        return $this->orderBy('tgl_aktivitas', 'DESC')->findAll($limit);
    }

    // ✅ Statistik jumlah notifikasi (dibaca/belum)
    public function countByStatusDibaca()
    {
        return $this->select('is_read, COUNT(*) as total')
                    ->groupBy('is_read')
                    ->findAll();
    }

    // ✅ Cari notifikasi berdasarkan kata kunci pesan
    public function cariPesan($keyword)
    {
        return $this->like('pesan', $keyword)->findAll();
    }

    // ✅ Filter berdasarkan tanggal notifikasi
    public function getByTanggal($tanggal)
    {
        return $this->where('DATE(tgl_aktivitas)', $tanggal)->findAll();
    }

    // ✅ Filter berdasarkan rentang tanggal
    public function getBetweenTanggal($start, $end)
    {
        return $this->where('tgl_aktivitas >=', $start)
                    ->where('tgl_aktivitas <=', $end)
                    ->orderBy('tgl_aktivitas', 'DESC')
                    ->findAll();
    }
}
