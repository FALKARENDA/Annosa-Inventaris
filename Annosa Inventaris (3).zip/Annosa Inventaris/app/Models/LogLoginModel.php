<?php

namespace App\Models;

use CodeIgniter\Model;

class LogLoginModel extends Model
{
    protected $table            = 'log_login';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';

    protected $allowedFields = [
        'user_id',
        'waktu_login',
        'ip_address',
        'status_login'
    ];

    public function getRecentLogin($limit = 5)
    {
        return $this->where('status_login', 'login')
                    ->orderBy('waktu_login', 'DESC')
                    ->findAll($limit);
    }

    public function getRecentLogout($limit = 5)
    {
        return $this->where('status_login', 'logout')
                    ->orderBy('waktu_login', 'DESC')
                    ->findAll($limit);
    }
}
