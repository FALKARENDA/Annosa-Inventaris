<?php

namespace App\Models;

use CodeIgniter\Model;

class PengecekanModel extends Model
{
    protected $table            = 'pengecekan';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';

    protected $allowedFields = [
        'inventaris_id',
        'tanggal_cek',
        'kondisi_terkini',
        'petugas_cek',
        'catatan'
    ];

    public function getWithInventaris()
{
    return $this->select('pengecekan.*, 
                          inventaris.id as inventaris_nomor,
                          barang.nama_barang')
                ->join('inventaris', 'inventaris.id = pengecekan.inventaris_id', 'left')
                ->join('barang', 'barang.id = inventaris.barang_id', 'left')
                ->orderBy('pengecekan.id', 'DESC') // GANTI DARI 'tanggal_cek'
                ->findAll();
}

}
