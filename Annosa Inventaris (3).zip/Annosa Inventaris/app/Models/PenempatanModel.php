<?php

namespace App\Models;

use CodeIgniter\Model;

class PenempatanModel extends Model
{
    protected $table            = 'penempatan';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';

    protected $allowedFields = [
        'inventaris_id',
        'lokasi_id',
        'tanggal',
        'keterangan',
        'tahun_anggaran'
    ];

    public function getWithRelasi()
    {
        return $this->select('penempatan.*, 
                              barang.kode_barang,
                              barang.nama_barang AS tipe,
                              barang.merk, 
                              barang.model, 
                              barang.warna,
                              lokasi.ruangan AS nama_lokasi,
                              lokasi.lantai,
                              lokasi.gedung')
                    ->join('inventaris', 'inventaris.id = penempatan.inventaris_id', 'left')
                    ->join('barang', 'barang.id = inventaris.barang_id', 'left')
                    ->join('lokasi', 'lokasi.id = penempatan.lokasi_id', 'left')
                    ->orderBy('penempatan.tanggal', 'DESC')
                    ->findAll();
    }
}
