<?php

namespace App\Models;

use CodeIgniter\Model;

class RiwayatStatusModel extends Model
{
    protected $table = 'riwayat_status_barang';
    protected $primaryKey = 'id_riwayat';
    protected $useAutoIncrement = true;
    protected $allowedFields = [
        'kode_barang', 'status_lama', 'status_baru', 'tgl_perubahan', 'user_id'
    ];
    protected $useTimestamps = false;
    protected $returnType = 'array';

    // ✅ Histori 1 barang
    public function getRiwayatByBarang($kode_barang)
    {
        return $this->where('kode_barang', $kode_barang)->orderBy('tgl_perubahan', 'DESC')->findAll();
    }

    // ✅ Histori + nama user
    public function getRiwayatWithUser()
    {
        return $this->select('riwayat_status_barang.*, user.nama_lengkap')
                    ->join('user', 'user.id_user = riwayat_status_barang.user_id')
                    ->orderBy('tgl_perubahan', 'DESC')
                    ->findAll();
    }

    // ✅ Histori + nama barang & user
    public function getFullRiwayat()
    {
        return $this->select('riwayat_status_barang.*, user.nama_lengkap, barang.nama_barang')
                    ->join('user', 'user.id_user = riwayat_status_barang.user_id')
                    ->join('barang', 'barang.kode_barang = riwayat_status_barang.kode_barang')
                    ->orderBy('tgl_perubahan', 'DESC')
                    ->findAll();
    }

    // ✅ Cari histori berdasarkan nama user
    public function cariByUser($nama)
    {
        return $this->select('riwayat_status_barang.*, user.nama_lengkap')
                    ->join('user', 'user.id_user = riwayat_status_barang.user_id')
                    ->like('user.nama_lengkap', $nama)
                    ->findAll();
    }

    // ✅ Cari histori berdasarkan nama barang
    public function cariByBarang($nama)
    {
        return $this->select('riwayat_status_barang.*, barang.nama_barang')
                    ->join('barang', 'barang.kode_barang = riwayat_status_barang.kode_barang')
                    ->like('barang.nama_barang', $nama)
                    ->findAll();
    }

    // ✅ Filter berdasarkan status lama
    public function getByStatusLama($status)
    {
        return $this->where('status_lama', $status)->findAll();
    }

    // ✅ Filter berdasarkan status baru
    public function getByStatusBaru($status)
    {
        return $this->where('status_baru', $status)->findAll();
    }

    // ✅ Statistik perubahan status (buat chart)
    public function countPerubahanStatus()
    {
        return $this->select('status_baru, COUNT(*) as total')
                    ->groupBy('status_baru')
                    ->findAll();
    }

    // ✅ Filter histori status dalam rentang tanggal
    public function getRiwayatBetween($start, $end)
    {
        return $this->where('tgl_perubahan >=', $start)
                    ->where('tgl_perubahan <=', $end)
                    ->findAll();
    }

    // ✅ Ambil status terbaru dari 1 barang
    public function getStatusTerakhirBarang($kode_barang)
    {
        return $this->where('kode_barang', $kode_barang)
                    ->orderBy('tgl_perubahan', 'DESC')
                    ->first();
    }
}
