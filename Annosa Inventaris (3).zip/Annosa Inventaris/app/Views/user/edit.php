<?= $this->extend('layouts/main'); ?>
<?= $this->section('content'); ?>

<div class="container py-4">
    <h4 class="fw-bold mb-4">Edit Data User</h4>

    <form action="<?= base_url('user/update/' . $user['id']) ?>" method="post">
        <div class="row g-3">
            <div class="col-md-6">
                <label for="username" class="form-label fw-semibold">Username</label>
                <input type="text" name="username" id="username" class="form-control" value="<?= esc($user['username']) ?>" required>
            </div>

            <div class="col-md-6">
                <label for="password" class="form-label fw-semibold">Password (opsional)</label>
                <input type="password" name="password" id="password" class="form-control" placeholder="Kosongkan jika tidak ingin ubah password">
            </div>

            <div class="col-md-6">
                <label for="level" class="form-label fw-semibold">Level</label>
                <select name="level" id="level" class="form-select" required>
                    <option value="" disabled>-- Pilih Level --</option>
                    <option value="admin" <?= $user['level'] === 'admin' ? 'selected' : '' ?>>Admin</option>
                    <option value="petugas" <?= $user['level'] === 'petugas' ? 'selected' : '' ?>>Petugas</option>
                    <option value="kepala" <?= $user['level'] === 'kepala' ? 'selected' : '' ?>>Kepala</option>
                </select>
            </div>

            <div class="col-md-6">
                <label for="status" class="form-label fw-semibold">Status</label>
                <select name="status" id="status" class="form-select" required>
                    <option value="" disabled>-- Pilih Status --</option>
                    <option value="aktif" <?= $user['status'] === 'aktif' ? 'selected' : '' ?>>Aktif</option>
                    <option value="nonaktif" <?= $user['status'] === 'nonaktif' ? 'selected' : '' ?>>Nonaktif</option>
                </select>
            </div>
        </div>

        <div class="mt-4">
            <button type="submit" class="btn btn-success rounded-pill px-4 fw-semibold">
                <i class="bi bi-save me-2"></i> Simpan Perubahan
            </button>
            <a href="<?= base_url('user') ?>" class="btn btn-secondary rounded-pill px-4 ms-2">Batal</a>
        </div>
    </form>
</div>

<?= $this->endSection(); ?>
