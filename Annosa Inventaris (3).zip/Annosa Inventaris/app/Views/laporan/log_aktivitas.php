<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>

<div class="container mt-4">
    <h4 class="mb-4">Riwayat Log Aktivitas</h4>

    <table class="table table-bordered table-hover">
        <thead class="table-secondary">
            <tr>
                <th>No</th>
                <th>Nama Barang</th>
                <th>Jenis Aktivitas</th>
                <th>Waktu</th>
                <th>Pelaku</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($log as $i => $entry): ?>
                <tr>
                    <td><?= $i + 1 ?></td>
                    <td><?= esc($entry['nama_barang']) ?></td>
                    <td><?= esc($entry['jenis_aktivitas']) ?></td>
                    <td><?= date('d-m-Y H:i', strtotime($entry['tgl_aktivitas'])) ?></td>
                    <td><?= esc($entry['nama_user']) ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<?= $this->endSection() ?>
