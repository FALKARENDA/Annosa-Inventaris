<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Laporan Barang</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            font-size: 12px;
            color: #333;
        }
        h3 {
            text-align: center;
            margin-bottom: 20px;
        }
        table {
            border-collapse: collapse;
            width: 100%;
        }
        th, td {
            border: 1px solid #000;
            padding: 6px 10px;
            text-align: left;
        }
        th {
            background-color: #f0f0f0;
        }
    </style>
</head>
<body>

<h3>Laporan Data Barang</h3>

<table>
    <thead>
        <tr>
            <th>No</th>
            <th>Nama Barang</th>
            <th>Kategori</th>
            <th>Status</th>
            <th>Tanggal Input</th>
        </tr>
    </thead>
    <tbody>
        <?php if (!empty($barang)): ?>
            <?php foreach ($barang as $index => $b): ?>
                <tr>
                    <td><?= $index + 1 ?></td>
                    <td><?= esc($b['nama_barang']) ?></td>
                    <td><?= esc($b['kategori']) ?></td>
                    <td><?= esc($b['status']) ?></td>
                    <td><?= date('d-m-Y', strtotime($b['tanggal_input'])) ?></td>
                </tr>
            <?php endforeach; ?>
        <?php else: ?>
            <tr>
                <td colspan="5" style="text-align: center;">Tidak ada data</td>
            </tr>
        <?php endif; ?>
    </tbody>
</table>

</body>
</html>
