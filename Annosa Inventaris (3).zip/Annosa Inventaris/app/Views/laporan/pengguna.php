<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>

<div class="container mt-4">
    <h4 class="mb-4">Laporan Pengguna Sistem</h4>

    <!-- Filter dan Export -->
    <form method="get" class="row g-2 mb-3">
        <div class="col-md-4">
            <input type="text" name="q" class="form-control" placeholder="Cari nama/email..." value="<?= esc($_GET['q'] ?? '') ?>">
        </div>
        <div class="col-md-3">
            <select name="role" class="form-select">
                <option value="">-- Semua Role --</option>
                <option value="admin" <?= ($_GET['role'] ?? '') == 'admin' ? 'selected' : '' ?>>Admin</option>
                <option value="user" <?= ($_GET['role'] ?? '') == 'user' ? 'selected' : '' ?>>User</option>
            </select>
        </div>
        <div class="col-md-5 d-flex justify-content-end">
            <button type="submit" class="btn btn-primary me-2"><i class="fas fa-filter"></i> Filter</button>
            <a href="<?= base_url('laporan/pengguna') ?>" class="btn btn-outline-secondary me-2"><i class="fas fa-sync"></i> Reset</a>
            <a href="<?= base_url('export/users') ?>" class="btn btn-success me-2"><i class="fas fa-file-excel"></i> Excel</a>
            <a href="<?= base_url('laporan/users-pdf') ?>" class="btn btn-danger"><i class="fas fa-file-pdf"></i> PDF</a>
        </div>
    </form>

    <!-- Tabel -->
    <table class="table table-striped table-bordered">
        <thead class="table-light">
            <tr>
                <th>No</th>
                <th>Nama</th>
                <th>Email</th>
                <th>Role</th>
                <th>Terdaftar Sejak</th>
            </tr>
        </thead>
        <tbody>
            <?php if (!empty($users)): ?>
                <?php foreach ($users as $index => $user): ?>
                    <tr>
                        <td><?= $index + 1 ?></td>
                        <td><?= esc($user['nama']) ?></td>
                        <td><?= esc($user['email']) ?></td>
                        <td><?= esc($user['role']) ?></td>
                        <td><?= date('d-m-Y', strtotime($user['created_at'])) ?></td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="5" class="text-center text-muted">Tidak ada data pengguna</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>

    <!-- Pagination -->
    <div class="mt-3">
        <?= $pager->links() ?? '' ?>
    </div>

    <!-- Tombol Cetak -->
    <div class="mt-3">
        <button onclick="window.print()" class="btn btn-outline-dark"><i class="fas fa-print"></i> Cetak</button>
    </div>
</div>

<?= $this->endSection() ?>
