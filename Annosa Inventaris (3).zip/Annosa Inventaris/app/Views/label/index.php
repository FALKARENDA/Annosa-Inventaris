<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>

<div class="p-4">
    <h2 class="fw-bold mb-4">Daftar Label Inventaris</h2>

    <table class="table table-bordered table-hover">
        <thead class="table-dark">
            <tr>
                <th>No</th>
                <th>Nama Barang</th>
                <th>Kode</th>
                <th>Lokasi</th>
                <th>Tahun</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $no = 1; foreach ($inventaris as $item): ?>
                <tr>
                    <td><?= $no++ ?></td>
                    <td><?= esc($item['tipe'] ?? '-') ?></td>
                    <td><?= esc($item['kode_barang'] ?? '-') ?></td>
                    <td><?= esc($item['ruangan'] ?? '-') ?> - Lt.<?= esc($item['lantai'] ?? '-') ?> - <?= esc($item['gedung'] ?? '-') ?></td>
                    <td><?= esc($item['tahun_anggaran'] ?? '-') ?></td>
                    <td>
                        <a href="<?= base_url('label/cetak/' . $item['id']) ?>" class="btn btn-sm btn-primary">
                            <i class="bi bi-printer"></i> Cetak
                        </a>
                    </td>
                </tr>
            <?php endforeach ?>
        </tbody>
    </table>
</div>

<?= $this->endSection() ?>
