<?= $this->extend('layouts/print') ?>
<?= $this->section('content') ?>

<div class="p-5">
    <h3 class="fw-bold mb-3">Label Inventaris</h3>

    <div class="mb-3">Nama Barang: <strong><?= esc($data['tipe']) ?></strong></div>
    <div class="mb-3">Kode Inventaris: <strong><?= esc($data['kode_barang']) ?></strong></div>
    <div class="mb-3">Lokasi: <strong><?= esc($data['ruangan']) ?> - Lt.<?= esc($data['lantai']) ?> - <?= esc($data['gedung']) ?></strong></div>
    <div class="mb-3">Tahun Anggaran: <strong><?= esc($data['tahun_anggaran']) ?></strong></div>
</div>

<?= $this->endSection() ?>
