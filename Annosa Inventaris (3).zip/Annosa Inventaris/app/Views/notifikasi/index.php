<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>

<div class="container mt-4">
    <h4 class="mb-3">Daftar Notifikasi</h4>

    <form class="row g-3 mb-3" method="get">
        <div class="col-md-4">
            <input type="text" name="search" class="form-control" placeholder="Cari pesan..." value="<?= esc($_GET['search'] ?? '') ?>">
        </div>
        <div class="col-md-3">
            <select name="status" class="form-select">
                <option value="">-- Semua Status --</option>
                <option value="belum" <?= ($_GET['status'] ?? '') === 'belum' ? 'selected' : '' ?>>Belum Dibaca</option>
            </select>
        </div>
        <div class="col-auto">
            <button class="btn btn-primary" type="submit">Filter</button>
            <a href="<?= base_url('notifikasi/bacaSemua') ?>" class="btn btn-success">Tandai Semua Dibaca</a>
        </div>
    </form>

    <table class="table table-bordered table-striped">
        <thead>
            <tr>
                <th>Pesan</th>
                <th>Barang</th>
                <th>Tanggal</th>
                <th>Status</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php if (empty($notifikasi)): ?>
                <tr><td colspan="5" class="text-center">Tidak ada notifikasi.</td></tr>
            <?php else: ?>
                <?php foreach ($notifikasi as $n): ?>
                    <tr class="<?= $n['status_dibaca'] ? '' : 'table-warning' ?>">
                        <td><?= esc($n['pesan']) ?></td>
                        <td><?= esc($n['nama_barang'] ?? '-') ?></td>
                        <td><?= date('d M Y H:i', strtotime($n['tgl_notifikasi'])) ?></td>
                        <td><?= $n['status_dibaca'] ? 'Dibaca' : '<strong>Belum</strong>' ?></td>
                        <td>
                            <?php if (!$n['status_dibaca']): ?>
                                <a href="<?= base_url('notifikasi/baca/' . $n['id_notifikasi']) ?>" class="btn btn-sm btn-success">Tandai Dibaca</a>
                            <?php endif ?>
                        </td>
                    </tr>
                <?php endforeach ?>
            <?php endif ?>
        </tbody>
    </table>
</div>

<?= $this->endSection() ?>
