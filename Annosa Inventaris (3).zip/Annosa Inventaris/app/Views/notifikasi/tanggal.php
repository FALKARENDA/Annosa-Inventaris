<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>

<div class="container mt-4">
    <h4 class="mb-3">Notifikasi Berdasarkan Tanggal</h4>

    <form method="get" class="mb-3 row g-2">
        <div class="col-md-3">
            <input type="date" name="tanggal" class="form-control" value="<?= esc($_GET['tanggal'] ?? '') ?>">
        </div>
        <div class="col-auto">
            <button class="btn btn-primary">Tampilkan</button>
        </div>
    </form>

    <ul class="list-group">
        <?php if (empty($notifikasi)): ?>
            <li class="list-group-item">Tidak ada notifikasi pada tanggal ini.</li>
        <?php else: ?>
            <?php foreach ($notifikasi as $n): ?>
                <li class="list-group-item">
                    <strong><?= esc($n['pesan']) ?></strong><br>
                    <small><?= date('d M Y H:i', strtotime($n['tgl_notifikasi'])) ?></small>
                </li>
            <?php endforeach ?>
        <?php endif ?>
    </ul>
</div>

<?= $this->endSection() ?>
