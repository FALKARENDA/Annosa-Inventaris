<!-- Views/notifikasi/penitipan_lama.php -->
<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>

<div class="container mt-4">
    <h4 class="mb-4">Notifikasi Barang Belum Diambil &gt; 7 Hari</h4>

    <?php if (!empty($notifikasi_penitipan)): ?>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Nama Barang</th>
                    <th>Tanggal Penitipan</th>
                    <th>Sudah (hari)</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($notifikasi_penitipan as $i => $row): ?>
                    <tr>
                        <td><?= $i + 1 ?></td>
                        <td><?= esc($row['nama_barang']) ?></td>
                        <td><?= date('d-m-Y', strtotime($row['tgl_aktivitas'])) ?></td>
                        <td><span class="badge bg-warning text-dark"><?= $row['hari'] ?> hari</span></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php else: ?>
        <div class="alert alert-info">Tidak ada barang yang belum diambil lebih dari 7 hari.</div>
    <?php endif; ?>
</div>

<?= $this->endSection() ?>
