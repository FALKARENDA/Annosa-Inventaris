<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>

<div class="container mt-4">
    <h4 class="mb-3">Riwayat Notifikasi Barang</h4>

    <a href="<?= base_url('notifikasi') ?>" class="btn btn-secondary mb-3">Kembali</a>

    <ul class="list-group">
        <?php if (empty($notifikasi)): ?>
            <li class="list-group-item">Tidak ada notifikasi untuk barang ini.</li>
        <?php else: ?>
            <?php foreach ($notifikasi as $n): ?>
                <li class="list-group-item d-flex justify-content-between align-items-center">
                    <?= esc($n['pesan']) ?>
                    <small><?= date('d M Y H:i', strtotime($n['tgl_notifikasi'])) ?></small>
                </li>
            <?php endforeach ?>
        <?php endif ?>
    </ul>
</div>

<?= $this->endSection() ?>
