<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Anossa Inventaris</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Bootstrap CSS & Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <!-- Custom Style -->
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
        }
        .sidebar {
            width: 230px;
            background-color: #e0eecd;
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            padding-top: 20px;
            overflow-y: auto;
            box-shadow: 2px 0 5px rgba(0,0,0,0.1);
        }
        .sidebar a {
            display: flex;
            align-items: center;
            padding: 10px 20px;
            color: #333;
            text-decoration: none;
            font-weight: 500;
            transition: 0.2s;
        }
        .sidebar a:hover, .sidebar a.active {
            background-color: #d0e0b9;
            color: #000;
        }
        .sidebar i {
            margin-right: 10px;
        }
        .main-content {
            margin-left: 230px;
            padding: 0;
            background-color: #f9f9f9;
        }
        .logo {
            text-align: center;
            margin-bottom: 30px;
        }
        .logo img {
            width: 100px;
            border-radius: 50%;
        }
        .logo h5 {
            margin-top: 10px;
            font-weight: bold;
            font-size: 16px;
        }
    </style>
</head>
<body>

<div class="sidebar">
    <div class="logo">
        <img src="<?= base_url('assets/img/logo.png') ?>" alt="Logo">
        <h5>Anossa Inventaris</h5>
    </div>
    <a href="<?= base_url('dashboard') ?>"><i class="bi bi-speedometer2"></i> Dashboard</a>
    <a href="<?= base_url('barang') ?>"><i class="bi bi-tags"></i> Data Barang</a>
    <a href="<?= base_url('user') ?>"><i class="bi bi-person-circle"></i> Manajemen User</a>
    <a href="<?= base_url('lokasi') ?>"><i class="bi bi-geo-alt"></i> Manajemen Lokasi</a>
    <a href="<?= base_url('inventaris') ?>"><i class="bi bi-buildings"></i> Inventaris</a>
    <a href="<?= base_url('penempatan') ?>"><i class="bi bi-person-bounding-box"></i> Penempatan</a>
    <a href="<?= base_url('mutasi') ?>"><i class="bi bi-repeat"></i> Mutasi</a>
    <a href="<?= base_url('setting') ?>"><i class="bi bi-gear"></i> Setting Sistem</a>
    <a href="<?= base_url('label') ?>"><i class="bi bi-upc-scan"></i> Label</a>
    <a href="<?= base_url('pengecekan') ?>"><i class="bi bi-check2-square"></i> Pengecekan</a>
    <a href="<?= base_url('peminjaman') ?>"><i class="bi bi-arrow-down-circle"></i> Peminjaman</a>
    <a href="<?= base_url('pengembalian') ?>"><i class="bi bi-arrow-up-circle"></i> Pengembalian</a>

    <?php if (session()->get('logged_in')) : ?>
        <a href="<?= base_url('auth/logout') ?>"><i class="bi bi-box-arrow-right"></i> Logout</a>
    <?php else : ?>
        <a href="<?= base_url('auth/login') ?>"><i class="bi bi-box-arrow-in-right"></i> Login</a>
    <?php endif; ?>
</div>

<div class="main-content">
    <?= $this->renderSection('content') ?>
</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
