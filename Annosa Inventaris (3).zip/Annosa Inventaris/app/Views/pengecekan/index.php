<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>

<div class="p-4">
    <h2 class="fw-bold mb-4">Pengecekan Inventaris</h2>

    <?php if (session()->getFlashdata('success')): ?>
        <div class="alert alert-success"><?= session()->getFlashdata('success') ?></div>
    <?php endif ?>

    <table class="table table-bordered table-striped">
        <thead class="table-dark text-center">
            <tr>
                <th>No</th>
                <th>Kategori</th>
                <th>Kode</th>
                <th>QR Code</th>
                <th>Lokasi</th>
                <th>Tahun Perolehan</th>
                <th>Kondisi</th>
                <th>Jumlah</th>
                <th>Dana</th>
                <th>Spesifikasi</th>
                <th>Foto</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $no = 1; foreach ($pengecekan as $item): ?>
                <tr>
                    <td class="text-center"><?= $no++ ?></td>
                    <td><?= esc($item['kategori'] ?? '-') ?></td>
                    <td><?= esc($item['kode_barang'] ?? '-') ?></td>
                    <td class="text-center">
                        <img src="<?= base_url('qrcode/' . $item['kode_barang'] . '.png') ?>" alt="QR" width="60">
                    </td>
                    <td><?= esc($item['ruangan']) ?> - Lt.<?= esc($item['lantai']) ?> - <?= esc($item['gedung']) ?></td>
                    <td class="text-center"><?= esc($item['tahun_perolehan']) ?></td>
                    <td><?= esc($item['kondisi']) ?></td>
                    <td class="text-center"><?= esc($item['jumlah']) ?></td>
                    <td><?= esc($item['dana']) ?></td>
                    <td><?= esc($item['catatan']) ?></td>
                    <td class="text-center">
                        <?php if (!empty($item['foto'])): ?>
                            <img src="<?= base_url('uploads/foto/' . $item['foto']) ?>" width="60">
                        <?php else: ?>
                            <span class="text-muted">-</span>
                        <?php endif ?>
                    </td>
                    <td class="text-center">
                        <a href="<?= base_url('pengecekan/edit/' . $item['id']) ?>" class="btn btn-sm btn-warning">
                            <i class="bi bi-pencil-square"></i>
                        </a>
                        <a href="<?= base_url('pengecekan/delete/' . $item['id']) ?>" class="btn btn-sm btn-danger" onclick="return confirm('Yakin ingin menghapus data ini?')">
                            <i class="bi bi-trash"></i>
                        </a>
                    </td>
                </tr>
            <?php endforeach ?>
        </tbody>
    </table>
</div>

<?= $this->endSection() ?>
