<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>

<div class="d-flex">
    <div class="flex-grow-1 p-4">

        <h2 class="fw-bold mb-4">Mutasi</h2>

        <div class="mb-3">
            <div class="fw-semibold bg-secondary-subtle px-3 py-2 rounded">Input Mutasi</div>
        </div>

        <form action="<?= base_url('mutasi/store') ?>" method="post">
            <div class="row mb-3">
                <div class="col-md-6">
                    <label for="tahun_anggaran" class="form-label fw-semibold">Tahun Anggaran</label>
                    <input type="number" name="tahun_anggaran" id="tahun_anggaran" class="form-control" placeholder="Mis. 2025" required>
                </div>
                <div class="col-md-6">
                    <label for="lokasi_awal" class="form-label fw-semibold">Lokasi Awal</label>
                    <select name="lokasi_awal" id="lokasi_awal" class="form-select" required>
                        <option value="">-- Pilih Lokasi Awal --</option>
                        <?php foreach ($lokasi as $row): ?>
                            <option value="<?= $row['id'] ?>">
                                <?= $row['ruangan'] ?> - Lt.<?= $row['lantai'] ?> - <?= $row['gedung'] ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>

            <div class="row mb-3">
                <div class="col-md-6">
                    <label for="kode_inventaris" class="form-label fw-semibold">Kode Inventaris</label>
                    <div class="input-group">
                        <select name="inventaris_id" class="form-select" required>
                            <option value="">-- Pilih Inventaris --</option>
                            <?php foreach ($inventaris as $inv): ?>
                                <option value="<?= $inv['id'] ?>">
                                    <?= $inv['kode_barang'] ?> - <?= $inv['tipe'] ?> (<?= $inv['merk'] ?> - <?= $inv['warna'] ?>)
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                <div class="col-md-6">
                    <label for="lokasi_tujuan" class="form-label fw-semibold">Lokasi Tujuan</label>
                    <select name="lokasi_tujuan" id="lokasi_tujuan" class="form-select" required>
                        <option value="">-- Pilih Lokasi Tujuan --</option>
                        <?php foreach ($lokasi as $row): ?>
                            <option value="<?= $row['id'] ?>">
                                <?= $row['ruangan'] ?> - Lt.<?= $row['lantai'] ?> - <?= $row['gedung'] ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>

            <div class="row mb-3">
                <div class="col-md-6">
                    <label for="tanggal_mutasi" class="form-label fw-semibold">Tanggal Mutasi</label>
                    <div class="input-group">
                        <input type="date" id="tanggal_mutasi" name="tanggal_mutasi" class="form-control rounded-start" required>
                        <span class="input-group-text rounded-end bg-dark text-white">
                            <i class="bi bi-calendar"></i>
                        </span>
                    </div>
                </div>
                <div class="col-md-6">
                    <label for="keterangan" class="form-label fw-semibold">Keterangan</label>
                    <textarea name="keterangan" id="keterangan" class="form-control" rows="2" placeholder="Tuliskan keterangan jika ada..."></textarea>
                </div>
            </div>

            <div class="mt-4 text-start">
                <button type="submit" class="btn btn-success rounded-pill px-4 fw-bold">
                    <i class="bi bi-bookmark-fill me-1"></i> Simpan Perubahan
                </button>
            </div>
        </form>

    </div>
</div>

<?= $this->endSection() ?>
