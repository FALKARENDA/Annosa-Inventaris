<?= $this->extend('layouts/main'); ?>
<?= $this->section('content'); ?>

<div class="container py-4">
    <h4 class="fw-bold mb-4">Tambah Data Lokasi</h4>

    <form action="<?= base_url('lokasi/store') ?>" method="post">
        <div class="row g-3">
            <div class="col-md-6">
                <label for="ruangan" class="form-label fw-semibold">Ruangan</label>
                <input type="text" name="ruangan" id="ruangan" class="form-control" required>
            </div>

            <div class="col-md-6">
                <label for="lantai" class="form-label fw-semibold">Lantai</label>
                <input type="text" name="lantai" id="lantai" class="form-control" required>
            </div>

            <div class="col-md-6">
                <label for="gedung" class="form-label fw-semibold">Gedung</label>
                <input type="text" name="gedung" id="gedung" class="form-control" required>
            </div>

            <div class="col-md-6">
                <label for="status" class="form-label fw-semibold">Status</label>
                <select name="status" id="status" class="form-select" required>
                    <option value="" disabled selected>-- Pilih Status --</option>
                    <option value="aktif">Aktif</option>
                    <option value="nonaktif">Nonaktif</option>
                </select>
            </div>
        </div>

        <div class="mt-4">
            <button type="submit" class="btn btn-success rounded-pill px-4 fw-semibold">
                <i class="bi bi-save me-2"></i> Simpan Lokasi
            </button>
            <a href="<?= base_url('lokasi') ?>" class="btn btn-secondary rounded-pill px-4 ms-2">Batal</a>
        </div>
    </form>
</div>

<?= $this->endSection(); ?>
