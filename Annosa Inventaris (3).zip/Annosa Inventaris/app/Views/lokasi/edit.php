<?= $this->extend('layouts/main'); ?>
<?= $this->section('content'); ?>

<div class="container py-4">
    <h4 class="fw-bold mb-4">Edit Data Lokasi</h4>

    <form action="<?= base_url('lokasi/update/' . $lokasi['id']) ?>" method="post">
        <div class="row g-3">
            <div class="col-md-6">
                <label for="ruangan" class="form-label fw-semibold">Ruangan</label>
                <input type="text" name="ruangan" id="ruangan" class="form-control" value="<?= esc($lokasi['ruangan']) ?>" required>
            </div>

            <div class="col-md-6">
                <label for="lantai" class="form-label fw-semibold">Lantai</label>
                <input type="text" name="lantai" id="lantai" class="form-control" value="<?= esc($lokasi['lantai']) ?>" required>
            </div>

            <div class="col-md-6">
                <label for="gedung" class="form-label fw-semibold">Gedung</label>
                <input type="text" name="gedung" id="gedung" class="form-control" value="<?= esc($lokasi['gedung']) ?>" required>
            </div>

            <div class="col-md-6">
                <label for="status" class="form-label fw-semibold">Status</label>
                <select name="status" id="status" class="form-select" required>
                    <option value="" disabled>-- Pilih Status --</option>
                    <option value="aktif" <?= $lokasi['status'] === 'aktif' ? 'selected' : '' ?>>Aktif</option>
                    <option value="nonaktif" <?= $lokasi['status'] === 'nonaktif' ? 'selected' : '' ?>>Nonaktif</option>
                </select>
            </div>
        </div>

        <div class="mt-4">
            <button type="submit" class="btn btn-success rounded-pill px-4 fw-semibold">
                <i class="bi bi-save me-2"></i> Simpan Perubahan
            </button>
            <a href="<?= base_url('lokasi') ?>" class="btn btn-secondary rounded-pill px-4 ms-2">Batal</a>
        </div>
    </form>
</div>

<?= $this->endSection(); ?>
