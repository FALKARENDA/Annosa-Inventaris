    <?= $this->extend('layouts/main') ?>
    <?= $this->section('content') ?>

    <div class="d-flex">
        <div class="flex-grow-1 p-4">

            <div class="d-flex justify-content-between align-items-center mb-4">
                <h2 class="fw-bold">Manajemen Lokasi</h2>
                <div class="d-flex align-items-center">
                    <input type="text" class="form-control form-control-sm me-3" placeholder="Cari..." style="width: 200px; border-radius: 20px;">
                    <a href="<?= base_url('lokasi/create') ?>" class="text-decoration-none fw-bold text-dark">+TAMBAH</a>
                </div>
            </div>

            <table class="table table-bordered table-striped align-middle text-center" style="border-collapse: collapse;">
                <thead style="background-color: #f5c6cb;">
                    <tr>
                        <th>Ruangan</th>
                        <th>Lantai</th>
                        <th>Gedung</th>
                        <th>Status</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($lokasi)) : ?>
                        <?php foreach ($lokasi as $row) : ?>
                            <tr>
                                <td><?= esc($row['ruangan']) ?></td>
                                <td><?= esc($row['lantai']) ?></td>
                                <td><?= esc($row['gedung']) ?></td>
                                <td><?= esc($row['status']) ?></td>
                                <td>
                                    <a href="<?= base_url('lokasi/edit/' . $row['id']) ?>" class="text-decoration-none me-2">
                                        ✏️ Edit
                                    </a>
                                    <a href="<?= base_url('lokasi/delete/' . $row['id']) ?>" class="text-decoration-none text-danger" onclick="return confirm('Yakin ingin menghapus?')">
                                        🗑️ Delete
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else : ?>
                        <tr>
                            <td colspan="5">Belum ada data lokasi.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>

            <div class="text-start mt-3">
                <button class="btn btn-success rounded-pill px-4 fw-bold" style="background-color: #78a890;">
                    <i class="bi bi-bookmark"></i> Simpan Perubahan
                </button>
            </div>

        </div>
    </div>

    <?= $this->endSection() ?>
