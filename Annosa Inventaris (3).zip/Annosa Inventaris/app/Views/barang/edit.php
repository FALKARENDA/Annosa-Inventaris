<?= $this->extend('layouts/main'); ?>
<?= $this->section('content'); ?>

<div class="container py-4">
    <h4 class="fw-bold mb-4">Edit Data Barang</h4>

    <form action="<?= base_url('barang/update/' . $barang['id']) ?>" method="post" enctype="multipart/form-data">
        <div class="row g-3">
            <div class="col-md-6">
                <label for="nama_barang" class="form-label fw-semibold">Nama Barang</label>
                <input type="text" name="nama_barang" id="nama_barang" class="form-control" value="<?= esc($barang['nama_barang']) ?>" required>
            </div>

            <div class="col-md-6">
                <label for="kode_barang" class="form-label fw-semibold">Kode Barang</label>
                <input type="text" name="kode_barang" id="kode_barang" class="form-control" value="<?= esc($barang['kode_barang']) ?>" required>
            </div>

            <div class="col-md-6">
                <label for="merk" class="form-label fw-semibold">Merk</label>
                <input type="text" name="merk" id="merk" class="form-control" value="<?= esc($barang['merk']) ?>">
            </div>

            <div class="col-md-6">
                <label for="model" class="form-label fw-semibold">Model</label>
                <input type="text" name="model" id="model" class="form-control" value="<?= esc($barang['model']) ?>">
            </div>

            <div class="col-md-6">
                <label for="warna" class="form-label fw-semibold">Warna</label>
                <input type="text" name="warna" id="warna" class="form-control" value="<?= esc($barang['warna']) ?>">
            </div>

            <div class="col-md-6">
                <label for="spesifikasi" class="form-label fw-semibold">Spesifikasi</label>
                <textarea name="spesifikasi" id="spesifikasi" class="form-control" rows="2"><?= esc($barang['spesifikasi']) ?></textarea>
            </div>

            <div class="col-md-6">
                <label for="foto" class="form-label fw-semibold">Foto Barang</label>
                <input type="file" name="foto" id="foto" class="form-control" accept="image/*">
                <?php if (!empty($barang['foto'])): ?>
                    <div class="mt-2">
                        <img src="<?= base_url('uploads/' . $barang['foto']) ?>" alt="Foto" class="img-thumbnail" style="max-height: 150px;">
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <div class="mt-4">
            <button type="submit" class="btn btn-primary rounded-pill px-4 fw-semibold">
                <i class="bi bi-pencil-square me-2"></i> Simpan Perubahan
            </button>
            <a href="<?= base_url('barang') ?>" class="btn btn-secondary rounded-pill px-4 ms-2">Batal</a>
        </div>
    </form>
</div>

<?= $this->endSection(); ?>
