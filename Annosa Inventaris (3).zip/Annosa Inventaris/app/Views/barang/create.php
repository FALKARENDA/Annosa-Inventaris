<?= $this->extend('layouts/main'); ?>
<?= $this->section('content'); ?>

<div class="container py-4">
    <h4 class="fw-bold mb-4">Tambah Data Barang</h4>

    <form action="<?= base_url('barang/store') ?>" method="post" enctype="multipart/form-data">
        <div class="row g-3">
            <div class="col-md-6">
                <label for="nama_barang" class="form-label fw-semibold">Nama Barang</label>
                <input type="text" name="nama_barang" id="nama_barang" class="form-control" required>
            </div>

            <div class="col-md-6">
                <label for="kode_barang" class="form-label fw-semibold">Kode Barang</label>
                <input type="text" name="kode_barang" id="kode_barang" class="form-control" required>
            </div>

            <div class="col-md-6">
                <label for="merk" class="form-label fw-semibold">Merk</label>
                <input type="text" name="merk" id="merk" class="form-control">
            </div>

            <div class="col-md-6">
                <label for="model" class="form-label fw-semibold">Model</label>
                <input type="text" name="model" id="model" class="form-control">
            </div>

            <div class="col-md-6">
                <label for="warna" class="form-label fw-semibold">Warna</label>
                <input type="text" name="warna" id="warna" class="form-control">
            </div>

            <div class="col-md-6">
                <label for="spesifikasi" class="form-label fw-semibold">Spesifikasi</label>
                <textarea name="spesifikasi" id="spesifikasi" class="form-control" rows="2"></textarea>
            </div>

            <div class="col-md-6">
                <label for="foto" class="form-label fw-semibold">Foto Barang</label>
                <input type="file" name="foto" id="foto" class="form-control" accept="image/*">
            </div>
        </div>

        <div class="mt-4">
            <button type="submit" class="btn btn-success rounded-pill px-4 fw-semibold">
                <i class="bi bi-save me-2"></i> Simpan Barang
            </button>
            <a href="<?= base_url('barang') ?>" class="btn btn-secondary rounded-pill px-4 ms-2">Batal</a>
        </div>
    </form>
</div>

<?= $this->endSection(); ?>
