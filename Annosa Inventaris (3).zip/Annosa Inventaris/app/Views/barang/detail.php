<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>

<div class="container mt-4">
    <h4 class="mb-3">Detail Barang</h4>

    <?php if ($barang): ?>
        <div class="card mb-4">
            <div class="card-body">
                <p><strong>Nama:</strong> <?= esc($barang['nama_barang']) ?></p>
                <p><strong>Kategori:</strong> <?= esc($barang['kategori']) ?></p>
                <p><strong>Lokasi:</strong> <?= esc($barang['lokasi']) ?></p>
                <p><strong>Deskripsi:</strong> <?= esc($barang['deskripsi'] ?? '-') ?></p>
                <p><strong>Status:</strong>
                    <span class="badge bg-<?= $barang['status'] === 'aktif' ? 'success' : ($barang['status'] === 'final' ? 'primary' : 'secondary') ?>">
                        <?= esc(ucfirst($barang['status'])) ?>
                    </span>
                </p>
                <p><strong>Tanggal Input:</strong> <?= date('d M Y', strtotime($barang['tanggal_input'])) ?></p>
            </div>
        </div>

        <!-- Gambar Barang -->
        <div class="mb-4">
            <h5>Gambar Barang</h5>
            <div class="row">
                <?php
                    $gambar = is_array($dokumen) ? array_filter($dokumen, fn($d) => preg_match('/\.(jpg|jpeg|png|gif)$/i', $d['url_file'] ?? '')) : [];
                ?>
                <?php if (!empty($gambar)): ?>
                    <?php foreach ($gambar as $img): ?>
                        <div class="col-md-3 mb-3">
                            <img src="<?= base_url($img['url_file']) ?>" class="img-fluid rounded border" style="max-height: 180px; object-fit: cover;" alt="Gambar Barang">
                        </div>
                    <?php endforeach ?>
                <?php else: ?>
                    <div class="text-muted ms-3">Belum ada gambar diunggah untuk barang ini.</div>
                <?php endif ?>
            </div>
        </div>

        <div class="row">
            <!-- Riwayat -->
            <div class="col-md-6 mb-4">
                <h5>Riwayat Status</h5>
                <ul class="list-group">
                    <?php foreach ($riwayat as $r): ?>
                        <li class="list-group-item">
                            <?= esc($r['status']) ?> —
                            <small class="text-muted"><?= date('d M Y', strtotime($r['tgl_perubahan'])) ?></small>
                        </li>
                    <?php endforeach ?>
                    <?php if (empty($riwayat)): ?>
                        <li class="list-group-item text-muted">Belum ada riwayat.</li>
                    <?php endif ?>
                </ul>
            </div>

            <!-- Dokumen -->
            <div class="col-md-6 mb-4">
                <h5>Dokumen Lainnya</h5>
                <ul class="list-group">
                    <?php
                        $dokumen_lain = is_array($dokumen) ? array_filter($dokumen, fn($d) => !preg_match('/\.(jpg|jpeg|png|gif)$/i', $d['url_file'] ?? '')) : [];
                    ?>
                    <?php foreach ($dokumen_lain as $d): ?>
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            <?= esc($d['tipe_dokumen']) ?>
                            <a href="<?= base_url($d['url_file']) ?>" target="_blank" class="btn btn-sm btn-outline-primary">
                                Lihat
                            </a>
                        </li>
                    <?php endforeach ?>
                    <?php if (empty($dokumen_lain)): ?>
                        <li class="list-group-item text-muted">Belum ada dokumen lainnya.</li>
                    <?php endif ?>
                </ul>
            </div>
        </div>

        <!-- Aktivitas -->
        <div class="mt-4">
            <h5>Aktivitas Terkait</h5>
            <ul class="list-group">
                <?php foreach ($aktivitas as $a): ?>
                    <li class="list-group-item">
                        <strong><?= ucfirst($a['jenis_aktivitas']) ?></strong>: <?= esc($a['deskripsi']) ?><br>
                        <small class="text-muted"><?= date('d M Y', strtotime($a['tgl_aktivitas'])) ?></small>
                    </li>
                <?php endforeach ?>
                <?php if (empty($aktivitas)): ?>
                    <li class="list-group-item text-muted">Tidak ada aktivitas terkait.</li>
                <?php endif ?>
            </ul>
        </div>

    <?php else: ?>
        <div class="alert alert-danger">Data barang tidak ditemukan.</div>
    <?php endif ?>

    <a href="<?= base_url('barang') ?>" class="btn btn-secondary mt-3"><i class="fas fa-arrow-left"></i> Kembali</a>
</div>

<?= $this->endSection() ?>
