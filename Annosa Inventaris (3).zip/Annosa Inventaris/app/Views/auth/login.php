<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Login - Anossa Inventaris</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap & FontAwesome -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">

    <style>
        body {
            margin: 0;
            padding: 0;
            height: 100vh;
            background: linear-gradient(135deg, rgb(130, 195, 199), #a8dadc);
            display: flex;
            justify-content: center;
            align-items: center;
            font-family: 'Segoe UI', sans-serif;
            transition: background 0.3s ease;
        }

        .card {
            border-radius: 20px;
            overflow: hidden;
            transition: background 0.3s, color 0.3s;
        }

        .card-header {
            background-color: #0b51d3;
            color: white;
        }

        .dark-mode {
            background-color: #121212 !important;
            color: #eee !important;
        }

        .form-control.dark-mode {
            background-color: #2c2c2c !important;
            color: #fff !important;
            border: 1px solid #444;
        }

        .form-check-label.dark-mode {
            color: #ccc !important;
        }

        .btn-toggle {
            background: none;
            border: none;
            color: #666;
            cursor: pointer;
            font-size: 14px;
        }

        .btn-toggle:hover {
            color: #000;
        }
    </style>
</head>
<body id="body">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-5 col-lg-4">
                <div class="card shadow" id="login-card">
                    <div class="card-header text-center">
                        <img src="<?= base_url('assets/img/logo.png') ?>" alt="Logo" class="rounded-circle border border-white mb-2" width="70" height="70">
                        <h4 class="mb-0">Login</h4>
                    </div>
                    <div class="card-body">
                        <?php if (session()->getFlashdata('success')): ?>
                            <div class="alert alert-success"><?= session()->getFlashdata('success') ?></div>
                        <?php endif; ?>
                        <?php if (session()->getFlashdata('error')): ?>
                            <div class="alert alert-danger"><?= session()->getFlashdata('error') ?></div>
                        <?php endif; ?>

                        <form method="POST" action="<?= base_url('auth/login') ?>" autocomplete="off">
                            <?= csrf_field() ?>
                            <div class="mb-3">
                                <input type="text" name="username" placeholder="USERNAME" class="form-control <?= isset($_COOKIE['remember_username']) ? 'is-valid' : '' ?>" required value="<?= $_COOKIE['remember_username'] ?? '' ?>">
                            </div>
                            <div class="mb-3">
                                <input type="password" name="password" placeholder="PASSWORD" class="form-control" required>
                            </div>
                            <div class="form-check mb-3">
                                <input class="form-check-input" type="checkbox" name="remember" id="remember" <?= isset($_COOKIE['remember_username']) ? 'checked' : '' ?>>
                                <label class="form-check-label" for="remember">Ingat saya</label>
                            </div>
                            <button type="submit" class="btn btn-primary w-100">
                                <i class="fas fa-sign-in-alt me-1"></i> Masuk
                            </button>
                        </form>
                    </div>
                    <div class="card-footer text-center">
                        <small>
                            <a href="<?= base_url('auth/forgot') ?>" class="text-muted d-block">Lupa password?</a>
                            <a href="<?= base_url('auth/register') ?>">Belum punya akun?</a>
                        </small>
                        <hr class="my-2">
                        <button onclick="toggleDarkMode()" class="btn btn-sm btn-outline-secondary">
                            <i class="fas fa-moon"></i> Ganti Tema
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>

<script>
    function toggleDarkMode() {
        document.body.classList.toggle('dark-mode');
        document.getElementById('login-card').classList.toggle('dark-mode');

        document.querySelectorAll('.form-control').forEach(el => el.classList.toggle('dark-mode'));
        document.querySelectorAll('.form-check-label').forEach(el => el.classList.toggle('dark-mode'));
    }
</script>
</body>
</html>
