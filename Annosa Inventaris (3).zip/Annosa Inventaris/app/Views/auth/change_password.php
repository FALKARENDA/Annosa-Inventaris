<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>
<style>
    body.dark-mode { background-color: #121212; color: #eee; }
    .card.dark-mode { background-color: #1e1e1e; color: #fff; }
    .form-control.dark-mode, .form-check-label.dark-mode {
        background-color: #2c2c2c; color: #fff;
    }
</style>

<div class="container d-flex align-items-center" style="min-height: 100vh;" id="body">
    <div class="row justify-content-center w-100">
        <div class="col-md-5 col-lg-4">
            <div class="card shadow-sm" id="login-card">
                <div class="card-header text-center bg-primary text-white">
                    <h4 class="mb-0">Ganti Password</h4>
                </div>
                <div class="card-body">
                    <?php if (session()->getFlashdata('success')): ?>
                        <div class="alert alert-success"><?= session()->getFlashdata('success') ?></div>
                    <?php endif; ?>
                    <?php if (session()->getFlashdata('error')): ?>
                        <div class="alert alert-danger"><?= session()->getFlashdata('error') ?></div>
                    <?php endif; ?>

                    <form method="POST" action="<?= base_url('user/password') ?>">
                        <?= csrf_field() ?>
                        <div class="mb-3">
                            <label for="password_lama" class="form-label">Password Lama</label>
                            <input type="password" name="password_lama" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label for="password_baru" class="form-label">Password Baru</label>
                            <input type="password" name="password_baru" class="form-control" required>
                        </div>
                        <button type="submit" class="btn btn-primary w-100">
                            <i class="fas fa-lock me-1"></i> Ubah Password
                        </button>
                    </form>
                </div>
                <div class="card-footer text-center">
                    <a href="<?= base_url('/dashboard') ?>" class="btn btn-link">← Kembali ke Dashboard</a>
                    <hr class="my-2">
                    <button onclick="toggleDarkMode()" class="btn btn-sm btn-outline-secondary">
                        <i class="fas fa-moon"></i> Ganti Tema
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    function toggleDarkMode() {
        document.body.classList.toggle('dark-mode');
        document.getElementById('login-card').classList.toggle('dark-mode');
        document.querySelectorAll('.form-control').forEach(el => el.classList.toggle('dark-mode'));
        document.querySelectorAll('.form-check-label').forEach(el => el.classList.toggle('dark-mode'));
    }
</script>
<?= $this->endSection() ?>
