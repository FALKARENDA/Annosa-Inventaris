<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Register - Anossa Inventaris</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap & FontAwesome -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">

    <style>
        body {
            background: linear-gradient(135deg, rgb(130, 195, 199), #a8dadc);
            height: 100vh;
            display: flex;
            align-items: center;
            font-family: 'Segoe UI', sans-serif;
        }
        .card {
            border-radius: 20px;
            transition: 0.3s;
        }
        .card-header {
            background-color: #0b51d3;
            color: white;
        }
    </style>
</head>
<body>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-5 col-lg-4">
            <div class="card shadow">
                <div class="card-header text-center">
                    <img src="<?= base_url('assets/img/logo.png') ?>" alt="Logo" class="rounded-circle border border-white mb-2" width="70" height="70">
                    <h4 class="mb-0">Buat Akun Baru</h4>
                </div>
                <div class="card-body">
                    <?php if (session()->getFlashdata('errors')): ?>
                        <div class="alert alert-danger">
                            <ul class="mb-0">
                                <?php foreach (session()->getFlashdata('errors') as $err): ?>
                                    <li><?= esc($err) ?></li>
                                <?php endforeach ?>
                            </ul>
                        </div>
                    <?php endif; ?>

                    <form method="POST" action="<?= base_url('auth/register') ?>">
                        <?= csrf_field() ?>

                        <div class="mb-3">
                            <input type="text" name="nama" placeholder="Nama Lengkap" class="form-control" required value="<?= old('nama') ?>">
                        </div>

                        <div class="mb-3">
                            <input type="text" name="username" placeholder="Username" class="form-control" required value="<?= old('username') ?>">
                        </div>

                        <div class="mb-3">
                            <input type="email" name="email" placeholder="Email" class="form-control" required value="<?= old('email') ?>">
                        </div>

                        <div class="mb-3">
                            <input type="password" name="password" placeholder="Password" class="form-control" required>
                        </div>

                        <button type="submit" class="btn btn-primary w-100">
                            <i class="fas fa-user-plus me-1"></i> Daftar
                        </button>
                    </form>
                </div>
                <div class="card-footer text-center">
                    <small>Sudah punya akun? <a href="<?= base_url('auth/login') ?>">Login di sini</a></small>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>
