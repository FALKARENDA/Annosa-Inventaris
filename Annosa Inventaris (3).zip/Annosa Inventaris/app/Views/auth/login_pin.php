<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Login PIN - Anossa Inventaris</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, rgb(130, 195, 199), #a8dadc);
            height: 100vh;
            display: flex;
            align-items: center;
            font-family: 'Segoe UI', sans-serif;
        }
        .card-header {
            background-color: #0b51d3;
            color: white;
        }
    </style>
</head>
<body>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-5 col-lg-4">
            <div class="card shadow rounded-4">
                <div class="card-header text-center">
                    <h4>Login PIN</h4>
                </div>
                <div class="card-body">
                    <?php if (session()->getFlashdata('error')): ?>
                        <div class="alert alert-danger"><?= session()->getFlashdata('error') ?></div>
                    <?php endif; ?>

                    <form method="POST" action="<?= base_url('auth/login-pin') ?>">
                        <?= csrf_field() ?>
                        <div class="mb-3">
                            <input type="text" name="username" placeholder="Username" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <input type="password" name="pin" placeholder="PIN" class="form-control" required>
                        </div>
                        <button type="submit" class="btn btn-warning w-100">Login dengan PIN</button>
                    </form>
                </div>
                <div class="card-footer text-center">
                    <a href="<?= base_url('auth/login') ?>">Login biasa</a>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>
