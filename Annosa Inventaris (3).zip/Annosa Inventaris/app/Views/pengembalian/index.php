<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>

<div class="d-flex justify-content-between align-items-center mb-3">
    <h2 class="fw-bold">Pengembalian</h2>
    <a href="<?= base_url('pengembalian/create') ?>" class="btn btn-outline-dark fw-semibold">+TAMBAH</a>
</div>

<div class="table-responsive mb-4">
    <table class="table table-bordered align-middle text-center">
        <thead class="table-danger text-dark">
            <tr>
                <th>No</th>
                <th>Kode</th>
                <th>Tanggal Kembali</th>
                <th>Jumlah Kembali</th>
                <th>Kondisi</th>
                <th>Catatan</th>
                <th>Status</th>
                <th>Petugas Terima</th>
                <th>Verifikasi</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php if (!empty($pengembalian)) : ?>
                <?php $no = 1; foreach ($pengembalian as $row) : ?>
                    <tr>
                        <td><?= $no++ ?></td>
                        <td><?= esc($row['kode_pengembalian']) ?></td>
                        <td><?= date('d M Y', strtotime($row['tanggal_pengembalian'])) ?></td>
                        <td><?= esc($row['jumlah_kembali']) ?> Unit</td>
                        <td><?= esc($row['kondisi_kembali']) ?></td>
                        <td><?= esc($row['catatan_kembali']) ?></td>
                        <td><?= esc($row['status']) ?></td>
                        <td><?= esc($row['petugas_terima']) ?></td>
                        <td><?= $row['verifikasi'] ? '✔' : '✘' ?></td>
                        <td class="text-nowrap">
                            <a href="<?= base_url('pengembalian/edit/' . $row['id']) ?>" class="text-decoration-none me-2">✏️ Edit</a>
                            <a href="<?= base_url('pengembalian/delete/' . $row['id']) ?>" class="text-decoration-none text-danger" onclick="return confirm('Yakin ingin menghapus data ini?')">🗑 Delete</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php else : ?>
                <tr>
                    <td colspan="10" class="text-center text-muted">Data tidak tersedia.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<div class="text-center">
    <button class="btn btn-success px-5 py-2 fw-semibold" disabled>
        <i class="bi bi-bookmark-fill me-2"></i> Simpan Perubahan
    </button>
</div>

<?= $this->endSection() ?>
