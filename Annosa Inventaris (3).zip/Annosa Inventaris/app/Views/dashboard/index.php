<?php echo $this->extend('layouts/main'); ?>
<?php echo $this->section('content'); ?>

<div class="d-flex">
    <div class="flex-grow-1 p-4">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2 class="fw-bold">Dashboard</h2>
            <div class="d-flex align-items-center">
                <select class="form-select me-2" style="width: 120px;">
                    <option>Bahasa</option>
                    <option>English</option>
                    <option>Indonesia</option>
                </select>
                <input type="text" class="form-control form-control-sm me-3" placeholder="Cari..." style="width: 200px; border-radius: 20px;">
                <div class="dropdown">
                    <i class="bi bi-bell-fill fs-5 text-secondary position-relative" data-bs-toggle="dropdown">
                        <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">3</span>
                    </i>
                    <ul class="dropdown-menu dropdown-menu-end shadow">
                        <li class="dropdown-header fw-bold">Notifikasi Terbaru</li>
                        <li><hr class="dropdown-divider"></li>
                        <li class="px-3 small text-muted">Pengembalian - Laptop Acer (1 jam lalu)</li>
                        <li class="px-3 small text-muted">Peminjaman - Printer Canon (2 jam lalu)</li>
                        <li class="px-3 small text-muted">Login oleh Admin (Hari ini, 09:12)</li>
                    </ul>
                </div>
            </div>
        </div>

        <div class="p-3 rounded mb-4" style="background-color: #dff0d8;">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <h5 class="fw-semibold">Comprehensive Inventory Management System</h5>
                    <p class="text-muted mb-0">Manage all your storage, items, and activities in one place.</p>
                </div>
                <img src="<?= base_url('assets/img/dashboard2.jpeg') ?>" alt="banner" style="height: 100px;">
            </div>
        </div>

        <div class="row g-3 mb-4">
            <?php
            $cards = [
                ['Inventaris', 'bi-buildings', 5],
                ['Lokasi', 'bi-geo-alt', 2],
                ['User', 'bi-person-circle', 3],
                ['Barang', 'bi-box-seam', 5],
                ['Penempatan', 'bi-person-bounding-box', 5],
                ['Label', 'bi-upc-scan', 5],
                ['Peminjaman', 'bi-arrow-down-circle', 6],
                ['Pengembalian', 'bi-arrow-up-circle', 4],
                ['Mutasi', 'bi-repeat', 3],
                ['Kategori Barang', 'bi-tags', 5],
                ['Log Login', 'bi-journal-text', 10],
                ['Pengecekan', 'bi-check2-square', 2],
                ['Setting Sistem', 'bi-gear', 1],
            ];
            foreach ($cards as [$title, $icon, $count]) : ?>
                <div class="col-6 col-sm-4 col-lg-2">
                    <div class="bg-light text-center p-3 rounded shadow-sm">
                        <i class="bi <?= $icon ?> fs-1 text-success"></i>
                        <div class="fw-bold mt-2"><?= $title ?></div>
                        <div><?= $count ?></div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>

        <div class="row g-4">
            <div class="col-md-6">
                <div class="card p-3">
                    <h6 class="fw-bold">Distribusi Kategori Barang</h6>
                    <canvas id="kategoriChart"></canvas>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card p-3">
                    <h6 class="fw-bold">Frekuensi Peminjaman Barang</h6>
                    <canvas id="peminjamanChart"></canvas>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card p-3">
                    <h6 class="fw-bold">Mutasi Barang per Bulan</h6>
                    <canvas id="mutasiChart"></canvas>
                </div>
            </div>
            <div class="col-md-6 text-center">
                <div class="card p-3">
                    <h6 class="fw-bold">Statistik Barang Masuk vs Keluar</h6>
                    <canvas id="barangStatChart"></canvas>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    new Chart(document.getElementById('kategoriChart'), {
        type: 'pie',
        data: {
            labels: ['Elektronik', 'Furnitur', 'ATK', 'Lainnya'],
            datasets: [{
                data: [35, 25, 20, 20],
                backgroundColor: ['#5cb85c', '#f0ad4e', '#d9534f', '#337ab7']
            }]
        },
        options: { responsive: true }
    });

    new Chart(document.getElementById('peminjamanChart'), {
        type: 'bar',
        data: {
            labels: ['Laptop', 'Printer', 'Proyektor', 'Scanner', 'Modem'],
            datasets: [{
                label: 'Jumlah',
                data: [12, 8, 15, 5, 9],
                backgroundColor: '#5bc0de'
            }]
        },
        options: {
            indexAxis: 'y',
            plugins: { legend: { display: false } },
            responsive: true
        }
    });

    new Chart(document.getElementById('mutasiChart'), {
        type: 'line',
        data: {
            labels: ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'],
            datasets: [{
                label: 'Mutasi',
                data: [10, 15, 8, 12, 9, 13, 14, 11, 16, 18, 12, 20],
                borderColor: '#337ab7',
                tension: 0.3,
                fill: false
            }]
        },
        options: { responsive: true, plugins: { legend: { display: false } } }
    });

    new Chart(document.getElementById('barangStatChart'), {
        type: 'bar',
        data: {
            labels: ['Masuk', 'Keluar'],
            datasets: [{
                label: 'Barang',
                data: [120, 85],
                backgroundColor: ['#5cb85c', '#d9534f']
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: { display: false }
            }
        }
    });
</script>

<?php echo $this->endSection(); ?>
