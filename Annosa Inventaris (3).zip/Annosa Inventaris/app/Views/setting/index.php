<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>

<div class="d-flex">
    <div class="flex-grow-1 p-4">
        <h2 class="fw-bold mb-4">Setting Sistem</h2>

        <div class="row">
            <div class="col-md-8">
                <h5 class="fw-semibold mb-3">Setting tampilan</h5>
                <form action="<?= base_url('setting/update') ?>" method="post">
                    <table class="table table-bordered align-middle text-center">
                        <thead class="table-danger">
                            <tr>
                                <th>No</th>
                                <th>Type</th>
                                <th>Jumlah</th>
                                <th>Kondisi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (!empty($tampilan)): ?>
                                <?php $no = 1; foreach ($tampilan as $row): ?>
                                    <tr>
                                        <td><?= $no++ ?></td>
                                        <td><input type="text" name="type[]" class="form-control" value="<?= esc($row['type']) ?>"></td>
                                        <td><input type="text" name="jumlah[]" class="form-control" value="<?= esc($row['jumlah']) ?>"></td>
                                        <td><input type="text" name="kondisi[]" class="form-control" value="<?= esc($row['kondisi']) ?>"></td>
                                    </tr>
                                <?php endforeach ?>
                            <?php else: ?>
                                <tr><td colspan="4">Tidak ada data pengaturan.</td></tr>
                            <?php endif ?>
                        </tbody>
                    </table>

                    <button type="submit" class="btn btn-success rounded-pill px-4 fw-bold">
                        <i class="bi bi-bookmark-fill me-1"></i> Terapakan kesemua
                    </button>
                </form>
            </div>

            <div class="col-md-4">
                <h5 class="fw-semibold">Tema</h5>
                <form action="<?= base_url('setting/theme') ?>" method="post">
                    <div class="border p-3 rounded">
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="theme" value="dark" id="dark" <?= $theme == 'dark' ? 'checked' : '' ?>>
                            <label class="form-check-label" for="dark">🌑 Hitam</label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="theme" value="light" id="light" <?= $theme == 'light' ? 'checked' : '' ?>>
                            <label class="form-check-label" for="light">🌞 Terang</label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="theme" value="pink" id="pink" <?= $theme == 'pink' ? 'checked' : '' ?>>
                            <label class="form-check-label" for="pink">🌸 Pink</label>
                        </div>

                        <button type="submit" class="btn btn-outline-dark mt-3 w-100">Simpan Tema</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?= $this->endSection() ?>
