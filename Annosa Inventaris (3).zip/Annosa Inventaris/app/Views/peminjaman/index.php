<?= $this->extend('layouts/main'); ?>
<?= $this->section('content'); ?>

<div class="d-flex">
    <div class="flex-grow-1 p-4">

        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2 class="fw-bold">Peminjaman Barang</h2>
            <div class="d-flex align-items-center">
                <input type="text" class="form-control form-control-sm me-3" placeholder="Cari..." style="width: 200px; border-radius: 20px;">
                <a href="<?= base_url('barang/create') ?>" class="text-decoration-none fw-bold text-dark">+TAMBAH</a>
            </div>
        </div>

        <form action="<?= base_url('barang/update_bulk') ?>" method="post">
            <div class="table-responsive">
                <table class="table table-bordered table-striped align-middle text-center" style="border-collapse: collapse;">
                    <thead style="background-color: #f5c6cb;">
                        <tr>
                            <th>No</th>
                            <th>Nama Barang</th>
                            <th>Kode</th>
                            <th>Merk</th>
                            <th>Model</th>
                            <th>Warna</th>
                            <th>Spesifikasi</th>
                            <th>Foto</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($items)) : $no = 1; foreach ($items as $item) : ?>
                            <tr>
                                <td><?= $no++ ?></td>
                                <td><input name="items[<?= $item['id'] ?>][nama_barang]" value="<?= esc($item['nama_barang']) ?>" class="form-control form-control-sm" /></td>
                                <td><input name="items[<?= $item['id'] ?>][kode_barang]" value="<?= esc($item['kode_barang']) ?>" class="form-control form-control-sm" /></td>
                                <td><input name="items[<?= $item['id'] ?>][merk]" value="<?= esc($item['merk']) ?>" class="form-control form-control-sm" /></td>
                                <td><input name="items[<?= $item['id'] ?>][model]" value="<?= esc($item['model']) ?>" class="form-control form-control-sm" /></td>
                                <td><input name="items[<?= $item['id'] ?>][warna]" value="<?= esc($item['warna']) ?>" class="form-control form-control-sm" /></td>
                                <td><input name="items[<?= $item['id'] ?>][spesifikasi]" value="<?= esc($item['spesifikasi']) ?>" class="form-control form-control-sm" /></td>
                                <td>
                                    <?php if (!empty($item['foto'])): ?>
                                        <img src="<?= base_url('uploads/' . $item['foto']) ?>" alt="Foto" style="height: 50px;">
                                    <?php else: ?>
                                        <span class="text-muted">-</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <a href="<?= base_url('barang/edit/' . $item['id']) ?>" class="text-decoration-none me-2">✏️ Edit</a>
                                    <a href="<?= base_url('barang/delete/' . $item['id']) ?>" class="text-decoration-none text-danger" onclick="return confirm('Yakin ingin hapus?')">🗑️ Hapus</a>
                                </td>
                            </tr>
                        <?php endforeach; else : ?>
                            <tr>
                                <td colspan="9" class="text-center text-muted">Belum ada data.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <div class="text-start mt-3">
                <button type="submit" class="btn btn-success rounded-pill px-4 fw-bold" style="background-color: #78a890;">
                    <i class="bi bi-bookmark"></i> Simpan Perubahan
                </button>
            </div>
        </form>

    </div>
</div>

<?= $this->endSection(); ?>
