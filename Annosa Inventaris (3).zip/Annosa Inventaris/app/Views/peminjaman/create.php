<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>

<div class="container mt-4">
    <h4 class="mb-3">Form Penitipan Barang</h4>

    <form method="post" action="<?= base_url('penitipan/store') ?>">
        <?= csrf_field() ?>

        <div class="mb-3">
            <label for="kode_barang" class="form-label">Pilih Barang</label>
            <select name="kode_barang" class="form-select" required>
                <option value="">-- Pilih Barang --</option>
                <?php foreach ($barang as $b): ?>
                   <option value="<?= $b['kode_barang'] ?>"><?= $b['nama_barang'] ?></option>

                <?php endforeach ?>
            </select>
        </div>

        <div class="mb-3">
            <label for="user_id" class="form-label">Pilih Penitip</label>
            <select name="user_id" class="form-select" required>
                <option value="">-- Pilih User --</option>
                <?php foreach ($user as $u): ?>
<option value="<?= $b['kode_barang'] ?>"><?= $b['nama_barang'] ?></option>

                <?php endforeach ?>
            </select>
        </div>

        <div class="mb-3">
            <label for="tanggal_titip" class="form-label">Tanggal Titip</label>
            <input type="date" name="tanggal_titip" class="form-control" required>
        </div>

        <div class="mb-3">
            <label for="durasi" class="form-label">Durasi (hari)</label>
            <input type="number" name="durasi" class="form-control" placeholder="Misal: 30" required>
        </div>

        <button class="btn btn-success"><i class="fas fa-save"></i> Simpan</button>
        <a href="<?= base_url('penitipan') ?>" class="btn btn-secondary">Kembali</a>
    </form>
</div>

<?= $this->endSection() ?>
