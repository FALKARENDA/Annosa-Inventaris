<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>

<div class="container mt-4">
    <h4 class="mb-3">Detail Penitipan Barang</h4>

    <div class="card mb-3">
        <div class="card-body">
            <p><strong>Nama Barang:</strong> <?= esc($penitipan['nama_barang']) ?></p>
            <p><strong>Penitip:</strong> <?= esc($penitipan['nama_user']) ?></p>
            <p><strong>Tanggal Titip:</strong> <?= date('d M Y', strtotime($penitipan['tanggal_titip'])) ?></p>
            <p><strong>Status:</strong> <?= esc($penitipan['status']) ?></p>
            <p><strong>Nilai Estimasi:</strong> Rp<?= number_format($penitipan['nilai_estimasi']) ?></p>
           <p><strong>Deskripsi:</strong><br><?= nl2br(esc($penitipan['deskripsi'] ?? 'Tidak ada deskripsi')) ?></p>
        </div>
    </div>

    <!-- Dokumen Terkait -->
    <div class="card">
        <div class="card-body">
            <h5>Dokumen Barang</h5>
            <ul class="list-group">
                <?php foreach ($dokumen as $d): ?>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        <?= esc($d['tipe_dokumen']) ?>
                        <a href="<?= base_url($d['url_file']) ?>" target="_blank">Lihat</a>
                    </li>
                <?php endforeach ?>
                <?php if (empty($dokumen)): ?>
                    <li class="list-group-item text-muted">Tidak ada dokumen.</li>
                <?php endif ?>
            </ul>
        </div>
    </div>
</div>

<?= $this->endSection() ?>
