<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>

<div class="container mt-4">
    <h4 class="mb-3">Edit Penitipan Barang</h4>

    <form action="<?= base_url('penitipan/update/' . $penitipan['id']) ?>" method="post">
        <?= csrf_field() ?>

        <div class="mb-3">
            <label for="kode_barang" class="form-label">Barang *</label>
            <select name="kode_barang" class="form-select" required>
                <option value="">-- Pilih Barang --</option>
                <?php foreach ($barang as $b): ?>
                    <option value="<?= $b['kode_barang'] ?>" <?= $penitipan['kode_barang'] == $b['kode_barang'] ? 'selected' : '' ?>>
                        <?= esc($b['nama_barang']) ?> (<?= $b['kode_barang'] ?>)
                    </option>
                <?php endforeach ?>
            </select>
        </div>

        <div class="mb-3">
            <label for="user_id" class="form-label">Penitip *</label>
            <select name="user_id" class="form-select" required>
                <option value="">-- Pilih Pengguna --</option>
                <?php foreach ($user as $u): ?>
                    <option value="<?= $u['id'] ?>" <?= $penitipan['user_id'] == $u['id'] ? 'selected' : '' ?>>
                        <?= esc($u['nama_lengkap']) ?>
                    </option>
                <?php endforeach ?>
            </select>
        </div>

        <div class="mb-3">
            <label for="tanggal_titip" class="form-label">Tanggal Titip *</label>
            <input type="date" name="tanggal_titip" class="form-control" value="<?= $penitipan['tanggal_titip'] ?>" required>
        </div>

        <div class="mb-3">
            <label for="durasi" class="form-label">Durasi Penitipan (hari)</label>
            <input type="number" name="durasi" class="form-control" value="<?= $penitipan['durasi'] ?>" required>
        </div>

        <div class="mb-3">
            <label for="nilai_estimasi" class="form-label">Nilai Estimasi</label>
<input type="number" name="nilai_estimasi" class="form-control" value="<?= isset($penitipan['nilai_estimasi']) ? $penitipan['nilai_estimasi'] : '' ?>">

        </div>

        <div class="mb-3">
            <label for="status" class="form-label">Status</label>
            <select name="status" class="form-select">
                <option value="aktif" <?= $penitipan['status'] == 'aktif' ? 'selected' : '' ?>>Aktif</option>
                <option value="selesai" <?= $penitipan['status'] == 'selesai' ? 'selected' : '' ?>>Selesai</option>
            </select>
        </div>

        <div class="mb-3">
            <label for="deskripsi" class="form-label">Deskripsi</label>
          <textarea name="deskripsi" class="form-control" rows="3">
    <?= isset($penitipan['deskripsi']) ? esc($penitipan['deskripsi']) : '' ?>
</textarea>

        </div>

        <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Simpan Perubahan</button>
        <a href="<?= base_url('penitipan') ?>" class="btn btn-secondary">Batal</a>
    </form>
</div>

<?= $this->endSection() ?>
