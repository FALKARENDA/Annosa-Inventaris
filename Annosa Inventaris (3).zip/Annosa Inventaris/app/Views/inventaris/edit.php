<?= $this->extend('layouts/main'); ?>
<?= $this->section('content'); ?>

<div class="container py-4">
    <h4 class="fw-bold mb-4">Edit Data Inventaris</h4>

    <form action="<?= base_url('inventaris/update/' . $inventaris['id']) ?>" method="post">
        <div class="row g-3">
            <div class="col-md-6">
                <label for="kode_barang" class="form-label fw-semibold">Kode Inventaris</label>
                <input type="text" name="kode_barang" id="kode_barang" class="form-control" value="<?= esc($inventaris['kode_barang']) ?>" required>
            </div>

            <div class="col-md-6">
                <label for="tipe" class="form-label fw-semibold">Tipe</label>
                <input type="text" name="tipe" id="tipe" class="form-control" value="<?= esc($inventaris['tipe']) ?>" required>
            </div>

            <div class="col-md-6">
                <label for="merk" class="form-label fw-semibold">Merk</label>
                <input type="text" name="merk" id="merk" class="form-control" value="<?= esc($inventaris['merk']) ?>">
            </div>

            <div class="col-md-6">
                <label for="model" class="form-label fw-semibold">Model</label>
                <input type="text" name="model" id="model" class="form-control" value="<?= esc($inventaris['model']) ?>">
            </div>

            <div class="col-md-6">
                <label for="warna" class="form-label fw-semibold">Warna</label>
                <input type="text" name="warna" id="warna" class="form-control" value="<?= esc($inventaris['warna']) ?>">
            </div>

            <div class="col-md-6">
                <label for="kondisi" class="form-label fw-semibold">Kondisi</label>
                <select name="kondisi" id="kondisi" class="form-select" required>
                    <option value="baik" <?= $inventaris['kondisi'] === 'baik' ? 'selected' : '' ?>>Baik</option>
                    <option value="rusak ringan" <?= $inventaris['kondisi'] === 'rusak ringan' ? 'selected' : '' ?>>Rusak Ringan</option>
                    <option value="rusak berat" <?= $inventaris['kondisi'] === 'rusak berat' ? 'selected' : '' ?>>Rusak Berat</option>
                </select>
            </div>

            <div class="col-md-6">
                <label for="jumlah" class="form-label fw-semibold">Jumlah</label>
                <input type="number" name="jumlah" id="jumlah" class="form-control" value="<?= esc($inventaris['jumlah']) ?>" required>
            </div>

            <div class="col-md-6">
                <label for="tahun_anggaran" class="form-label fw-semibold">Tahun Anggaran</label>
                <input type="text" name="tahun_anggaran" id="tahun_anggaran" class="form-control" value="<?= esc($inventaris['tahun_anggaran']) ?>" required>
            </div>

            <div class="col-md-6">
                <label for="lokasi_id" class="form-label fw-semibold">Lokasi</label>
                <select name="lokasi_id" id="lokasi_id" class="form-select" required>
                    <?php foreach ($lokasi as $row): ?>
                        <option value="<?= $row['id'] ?>" <?= $row['id'] == $inventaris['lokasi_id'] ? 'selected' : '' ?>>
                            <?= $row['ruangan'] ?> (Lt. <?= $row['lantai'] ?> - <?= $row['gedung'] ?>)
                        </option>
                    <?php endforeach ?>
                </select>
            </div>
        </div>

        <div class="mt-4">
            <button type="submit" class="btn btn-success rounded-pill px-4 fw-semibold">
                <i class="bi bi-save me-2"></i> Simpan Perubahan
            </button>
            <a href="<?= base_url('inventaris') ?>" class="btn btn-secondary rounded-pill px-4 ms-2">Batal</a>
        </div>
    </form>
</div>

<?= $this->endSection(); ?>
