<?= $this->extend('layouts/main'); ?>
<?= $this->section('content'); ?>

<div class="container py-4">
    <h4 class="fw-bold mb-4">Tambah Data Inventaris</h4>

    <form action="<?= base_url('inventaris/store') ?>" method="post">
        <div class="row g-3">
            <div class="col-md-6">
                <label for="kode_barang" class="form-label fw-semibold">Kode Inventaris</label>
                <input type="text" name="kode_barang" id="kode_barang" class="form-control" required>
            </div>

            <div class="col-md-6">
                <label for="tipe" class="form-label fw-semibold">Tipe</label>
                <input type="text" name="tipe" id="tipe" class="form-control" required>
            </div>

            <div class="col-md-6">
                <label for="merk" class="form-label fw-semibold">Merk</label>
                <input type="text" name="merk" id="merk" class="form-control">
            </div>

            <div class="col-md-6">
                <label for="model" class="form-label fw-semibold">Model</label>
                <input type="text" name="model" id="model" class="form-control">
            </div>

            <div class="col-md-6">
                <label for="warna" class="form-label fw-semibold">Warna</label>
                <input type="text" name="warna" id="warna" class="form-control">
            </div>

            <div class="col-md-6">
                <label for="kondisi" class="form-label fw-semibold">Kondisi</label>
                <select name="kondisi" id="kondisi" class="form-select" required>
                    <option value="" disabled selected>-- Pilih Kondisi --</option>
                    <option value="baik">Baik</option>
                    <option value="rusak ringan">Rusak Ringan</option>
                    <option value="rusak berat">Rusak Berat</option>
                </select>
            </div>

            <div class="col-md-6">
                <label for="jumlah" class="form-label fw-semibold">Jumlah</label>
                <input type="number" name="jumlah" id="jumlah" class="form-control" required>
            </div>

            <div class="col-md-6">
                <label for="tahun_anggaran" class="form-label fw-semibold">Tahun Anggaran</label>
                <input type="text" name="tahun_anggaran" id="tahun_anggaran" class="form-control" required>
            </div>

            <div class="col-md-6">
                <label for="lokasi_id" class="form-label fw-semibold">Lokasi</label>
                <select name="lokasi_id" id="lokasi_id" class="form-select" required>
                    <option value="" disabled selected>-- Pilih Lokasi --</option>
                    <?php foreach ($lokasi as $row): ?>
                        <option value="<?= $row['id'] ?>">
                            <?= $row['ruangan'] ?> (Lt. <?= $row['lantai'] ?> - <?= $row['gedung'] ?>)
                        </option>
                    <?php endforeach ?>
                </select>
            </div>
        </div>

        <div class="mt-4">
            <button type="submit" class="btn btn-success rounded-pill px-4 fw-semibold">
                <i class="bi bi-save me-2"></i> Simpan Inventaris
            </button>
            <a href="<?= base_url('inventaris') ?>" class="btn btn-secondary rounded-pill px-4 ms-2">Batal</a>
        </div>
    </form>
</div>

<?= $this->endSection(); ?>
