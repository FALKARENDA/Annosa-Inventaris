<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>

<div class="d-flex">
    <div class="flex-grow-1 p-4">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2 class="fw-bold">Inventaris</h2>
            <div class="d-flex align-items-center">
                <input type="text" class="form-control form-control-sm me-3" placeholder="Cari..." style="width: 200px; border-radius: 20px;">
                <a href="<?= base_url('inventaris/create') ?>" class="text-decoration-none fw-bold text-dark">+TAMBAH</a>
            </div>
        </div>

        <table class="table table-bordered table-striped align-middle text-center">
            <thead style="background-color: #f5c6cb;">
                <tr>
                    <th>Kode Inventaris</th>
                    <th>Type</th>
                    <th>Merk</th>
                    <th>Model</th>
                    <th>Warna</th>
                    <th>Kondisi</th>
                    <th>Jumlah</th>
                    <th>Lokasi</th>
                    <th>Tahun</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($inventaris)) : ?>
                    <?php foreach ($inventaris as $item) : ?>
                        <tr>
                            <td><?= esc($item['kode_barang']) ?></td>
                            <td><?= esc($item['tipe']) ?></td>
                            <td><?= esc($item['merk']) ?></td>
                            <td><?= esc($item['model']) ?></td>
                            <td><?= esc($item['warna']) ?></td>
                            <td><?= esc($item['kondisi']) ?></td>
                            <td><?= esc($item['jumlah']) ?></td>
                            <td><?= esc($item['ruangan']) ?> (Lt. <?= esc($item['lantai']) ?> - <?= esc($item['gedung']) ?>)</td>
                            <td><?= esc($item['tahun_anggaran']) ?></td>
                            <td>
                                <a href="<?= base_url('inventaris/edit/' . $item['id']) ?>" class="text-decoration-none me-2">✏️ Edit</a>
                                <a href="<?= base_url('inventaris/delete/' . $item['id']) ?>" class="text-decoration-none text-danger" onclick="return confirm('Yakin ingin menghapus?')">🗑️ Delete</a>
                            </td>
                        </tr>
                    <?php endforeach ?>
                <?php else : ?>
                    <tr><td colspan="10">Belum ada data inventaris.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>

        <div class="text-start mt-3">
            <button class="btn btn-success rounded-pill px-4 fw-bold" style="background-color: #78a890;">
                <i class="bi bi-bookmark"></i> Simpan Perubahan
            </button>
        </div>
    </div>
</div>

<?= $this->endSection() ?>
