<?= $this->extend('layouts/main'); ?>
<?= $this->section('content'); ?>

<div class="d-flex">
    <div class="flex-grow-1 p-4">

        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2 class="fw-bold">Edit Penempatan</h2>
            <a href="<?= base_url('penempatan') ?>" class="btn btn-secondary rounded-pill fw-bold px-4">Kembali</a>
        </div>

        <form action="<?= base_url('penempatan/update/' . $penempatan['id']) ?>" method="post">
            <table class="table table-bordered text-center align-middle">
                <thead style="background-color: #f5c6cb;">
                    <tr>
                        <th>Tanggal</th>
                        <th>Kode Barang</th>
                        <th>Jenis</th>
                        <th>Merk</th>
                        <th>Lokasi</th>
                        <th>Tahun Anggaran</th>
                        <th>Keterangan</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>
                            <input type="date" name="tanggal" class="form-control form-control-sm" value="<?= esc($penempatan['tanggal']) ?>" required>
                        </td>
                        <td>
                            <input type="text" class="form-control form-control-sm text-center" value="<?= esc($penempatan['kode_barang']) ?>" disabled>
                        </td>
                        <td>
                            <input type="text" class="form-control form-control-sm text-center" value="<?= esc($penempatan['tipe']) ?>" disabled>
                        </td>
                        <td>
                            <input type="text" class="form-control form-control-sm text-center" value="<?= esc($penempatan['merk']) ?>" disabled>
                        </td>
                        <td>
                            <select name="lokasi_id" class="form-select form-select-sm" required>
                                <?php foreach ($lokasi as $lok): ?>
                                    <option value="<?= $lok['id'] ?>" <?= $lok['id'] == $penempatan['lokasi_id'] ? 'selected' : '' ?>>
                                        <?= esc($lok['nama_lokasi']) ?> (Lt.<?= esc($lok['lantai']) ?> - <?= esc($lok['gedung']) ?>)
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </td>
                        <td>
                            <input type="number" name="tahun_anggaran" class="form-control form-control-sm text-center" value="<?= esc($penempatan['tahun_anggaran']) ?>" required>
                        </td>
                        <td>
                            <input type="text" name="keterangan" class="form-control form-control-sm" value="<?= esc($penempatan['keterangan']) ?>">
                        </td>
                    </tr>
                </tbody>
            </table>

            <div class="text-start mt-3">
                <button type="submit" class="btn btn-success rounded-pill px-4 fw-bold" style="background-color: #78a890;">
                    <i class="bi bi-save me-1"></i> Simpan Perubahan
                </button>
                <a href="<?= base_url('penempatan') ?>" class="btn btn-outline-secondary rounded-pill px-4 ms-2 fw-bold">Batal</a>
            </div>
        </form>

    </div>
</div>

<?= $this->endSection(); ?>
