<?= $this->extend('layouts/main'); ?>
<?= $this->section('content'); ?>

<div class="container py-4">
    <h4 class="fw-bold mb-4">Tambah Data Penempatan</h4>

    <form action="<?= base_url('penempatan/store') ?>" method="post">
    <input type="hidden" name="<?= csrf_token() ?>" value="<?= csrf_hash() ?>">

    <label>Inventaris</label>
    <select name="inventaris_id" required>
        <?php foreach ($inventaris as $item): ?>
            <option value="<?= $item['id'] ?>"><?= $item['kode_barang'] ?> - <?= $item['nama_barang'] ?></option>
        <?php endforeach; ?>
    </select>

    <label>Lokasi</label>
    <select name="lokasi_id" required>
        <?php foreach ($lokasi as $lok): ?>
            <option value="<?= $lok['id'] ?>"><?= $lok['ruangan'] ?></option>
        <?php endforeach; ?>
    </select>

    <input type="date" name="tanggal" required>
    <input type="text" name="tahun_anggaran" required>
    <textarea name="keterangan"></textarea>


        <div class="mt-4">
            <button type="submit" class="btn btn-success rounded-pill px-4 fw-semibold">
                <i class="bi bi-save me-2"></i> Simpan Penempatan
            </button>
            <a href="<?= base_url('penempatan') ?>" class="btn btn-secondary rounded-pill px-4 ms-2">Batal</a>
        </div>
    </form>
</div>

<?= $this->endSection(); ?>
