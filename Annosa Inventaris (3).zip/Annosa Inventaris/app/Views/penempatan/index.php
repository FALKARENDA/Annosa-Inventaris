<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>

<div class="d-flex">
    <div class="flex-grow-1 p-4">

        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2 class="fw-bold">Daftar Penempatan</h2>
            <div class="d-flex align-items-center">
                <input type="text" class="form-control form-control-sm me-3" placeholder="Cari..." style="width: 200px; border-radius: 20px;">
                <a href="<?= base_url('penempatan/create') ?>" class="text-decoration-none fw-bold text-dark">+TAMBAH</a>
            </div>
        </div>

        <form action="<?= base_url('penempatan/update_bulk') ?>" method="post">
            <table class="table table-bordered table-striped text-center align-middle">
                <thead style="background-color: #f5c6cb;">
                    <tr>
                        <th>Tanggal</th>
                        <th>Kode Barang</th>
                        <th>Jenis</th>
                        <th>Merk</th>
                        <th>Lokasi</th>
                        <th>Tahun Anggaran</th>
                        <th>Keterangan</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($penempatan)) : ?>
                        <?php foreach ($penempatan as $i => $row) : ?>
                            <tr>
                                <input type="hidden" name="data[<?= $i ?>][id]" value="<?= $row['id'] ?>">

                                <td>
                                    <input type="date" name="data[<?= $i ?>][tanggal]" class="form-control form-control-sm" value="<?= esc($row['tanggal']) ?>">
                                </td>
                                <td><?= esc($row['kode_barang']) ?></td>
                                <td><?= esc($row['tipe']) ?></td>
                                <td><?= esc($row['merk']) ?></td>
                                <td><?= esc($row['ruangan'] ?? '-') ?> (Lt.<?= esc($row['lantai'] ?? '-') ?> - <?= esc($row['gedung'] ?? '-') ?>)</td>
                                <td>
                                    <input type="text" name="data[<?= $i ?>][tahun_anggaran]" class="form-control form-control-sm text-center" value="<?= esc($row['tahun_anggaran']) ?>">
                                </td>
                                <td>
                                    <input type="text" name="data[<?= $i ?>][keterangan]" class="form-control form-control-sm" value="<?= esc($row['keterangan']) ?>">
                                </td>
                                <td>
                                    <a href="<?= base_url('penempatan/edit/' . $row['id']) ?>" class="text-decoration-none me-2">✏️</a>
                                    <a href="<?= base_url('penempatan/delete/' . $row['id']) ?>" class="text-danger text-decoration-none" onclick="return confirm('Yakin hapus?')">🗑️</a>
                                </td>
                            </tr>
                        <?php endforeach ?>
                    <?php else : ?>
                        <tr><td colspan="8">Belum ada data penempatan.</td></tr>
                    <?php endif ?>
                </tbody>
            </table>

            <div class="text-start mt-3">
                <button type="submit" class="btn btn-success rounded-pill px-4 fw-bold" style="background-color: #78a890;">
                    <i class="bi bi-bookmark"></i> Simpan Perubahan
                </button>
            </div>
        </form>

    </div>
</div>

<?= $this->endSection() ?>
