<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>

<div class="container mt-4">
    <h4 class="mb-3">Daftar Kategori</h4>

    <?php if (session()->getFlashdata('success')): ?>
        <div class="alert alert-success"><?= session()->getFlashdata('success') ?></div>
    <?php endif; ?>
    <?php if (session()->getFlashdata('error')): ?>
        <div class="alert alert-danger"><?= session()->getFlashdata('error') ?></div>
    <?php endif; ?>

    <div class="d-flex justify-content-between mb-3">
        <a href="<?= base_url('kategori/create') ?>" class="btn btn-primary">
            <i class="fas fa-plus"></i> Tambah Kategori
        </a>
        <div>
            <a href="<?= base_url('kategori/export') ?>" class="btn btn-success me-2">
                <i class="fas fa-file-excel"></i> Export
            </a>
            <form class="d-inline" method="get">
                <div class="input-group">
                    <input type="text" name="q" class="form-control" placeholder="Cari kategori..." value="<?= esc($_GET['q'] ?? '') ?>">
                    <button class="btn btn-outline-secondary" type="submit"><i class="fas fa-search"></i></button>
                </div>
            </form>
        </div>
    </div>

    <table class="table table-bordered table-hover">
        <thead class="table-light">
            <tr>
                <th>No</th>
                <th>Nama Kategori</th>
                <th>Keterangan</th>
                <th>Jumlah Barang</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php if (!empty($kategori)): ?>
                <?php foreach ($kategori as $i => $k): ?>
                    <tr>
                        <td><?= $i + 1 + ((int) ($_GET['page'] ?? 1) - 1) * 10 ?></td>
                        <td><?= esc($k['nama_kategori']) ?></td>
                        <td><?= esc($k['keterangan']) ?></td>
                        <td><?= esc($k['total_barang'] ?? 0) ?></td>
                        <td>
                            <a href="<?= base_url('barang?kategori_id=' . $k['id']) ?>" class="btn btn-sm btn-info">
                                <i class="fas fa-box"></i> Lihat Barang
                            </a>
                            <a href="<?= base_url('kategori/edit/' . $k['id']) ?>" class="btn btn-sm btn-warning"><i class="fas fa-edit"></i></a>
                            <form action="<?= base_url('kategori/delete/' . $k['id']) ?>" method="post" class="d-inline" onsubmit="return confirm('Hapus kategori ini?')">
                                <?= csrf_field() ?>
                                <button class="btn btn-sm btn-danger"><i class="fas fa-trash"></i></button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach ?>
            <?php else: ?>
                <tr><td colspan="5" class="text-center text-muted">Tidak ada data kategori.</td></tr>
            <?php endif ?>
        </tbody>
    </table>

    <div class="d-flex justify-content-center">
        <?= $pager->links() ?>
    </div>
</div>

<?= $this->endSection() ?>
