<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>

<div class="container mt-4">
    <h4 class="mb-3">Edit Kategori</h4>

    <?php if (session()->getFlashdata('error')): ?>
        <div class="alert alert-danger"><?= session()->getFlashdata('error') ?></div>
    <?php endif; ?>

    <form action="<?= base_url('kategori/update/' . $kategori['id']) ?>" method="post">
        <?= csrf_field() ?>

        <div class="mb-3">
            <label for="nama_kategori" class="form-label">Nama Kategori</label>
            <input type="text" class="form-control" name="nama_kategori" value="<?= esc($kategori['nama_kategori']) ?>" required>
        </div>

        <div class="mb-3">
            <label for="keterangan" class="form-label">Keterangan</label>
            <textarea class="form-control" name="keterangan" rows="3"><?= esc($kategori['keterangan']) ?></textarea>
        </div>

        <button class="btn btn-primary"><i class="fas fa-save"></i> Update</button>
        <a href="<?= base_url('kategori') ?>" class="btn btn-secondary">Batal</a>
    </form>
</div>

<?= $this->endSection() ?>
