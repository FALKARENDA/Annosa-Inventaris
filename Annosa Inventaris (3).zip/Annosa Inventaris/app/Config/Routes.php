<?php

namespace Config;

use CodeIgniter\Routing\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes = Services::routes();

// ✅ DEFAULT
$routes->setDefaultNamespace('App\\Controllers');
$routes->setDefaultController('DashboardController');
$routes->setDefaultMethod('index');
$routes->setTranslateURIDashes(false);
$routes->set404Override();
$routes->setAutoRoute(false);

// ✅ AUTH
$routes->get('auth/login', 'LoginController::index');
$routes->post('auth/login', 'LoginController::login');
$routes->get('auth/register', 'LoginController::registerForm');
$routes->post('auth/register', 'LoginController::register');
$routes->get('auth/logout', 'LoginController::logout');
$routes->match(['get', 'post'], 'auth/forgot', 'ForgotController::index');
$routes->post('auth/forgot', 'ForgotController::reset');
$routes->match(['get', 'post'], 'auth/login-pin', 'LoginController::loginPin');

// ✅ REDIRECT (Legacy)
$routes->get('login', fn() => redirect()->to('/auth/login'));
$routes->get('register', fn() => redirect()->to('/auth/register'));
$routes->get('logout', fn() => redirect()->to('/auth/logout'));

// ✅ DASHBOARD
$routes->get('/', 'DashboardController::index');
$routes->get('dashboard', 'DashboardController::index');

// ✅ BARANG
$routes->get('barang', 'BarangController::index');
$routes->get('barang/create', 'BarangController::create');
$routes->post('barang/store', 'BarangController::store');
$routes->get('barang/edit/(:segment)', 'BarangController::edit/$1');
$routes->post('barang/update/(:segment)', 'BarangController::update/$1');
$routes->get('barang/delete/(:segment)', 'BarangController::delete/$1');
$routes->get('barang/detail/(:segment)', 'BarangController::detail/$1');
$routes->post('barang/update_bulk', 'BarangController::update_bulk');
$routes->get('barang/export/excel', 'BarangController::exportExcel');
$routes->get('barang/export/pdf', 'BarangController::exportPDF');

// ✅ INVENTARIS
$routes->get('inventaris', 'InventarisController::index');
$routes->get('inventaris/create', 'InventarisController::create');
$routes->post('inventaris/store', 'InventarisController::store');
$routes->get('inventaris/edit/(:num)', 'InventarisController::edit/$1');
$routes->post('inventaris/update/(:num)', 'InventarisController::update/$1');
$routes->get('inventaris/delete/(:num)', 'InventarisController::delete/$1');
$routes->get('inventaris/detail/(:num)', 'InventarisController::detail/$1');
$routes->get('inventaris/export/excel', 'InventarisController::exportExcel');
$routes->get('inventaris/export/pdf', 'InventarisController::exportPDF');

// ✅ LABEL
$routes->get('label', 'LabelController::index');
$routes->get('label/print/(:num)', 'LabelController::print/$1');
$routes->get('label/download/(:num)', 'LabelController::download/$1');
$routes->get('label/export/excel', 'LabelController::exportExcel');
$routes->get('label/export/pdf', 'LabelController::exportPDF');

// ✅ MUTASI
$routes->get('mutasi', 'MutasiController::index');
$routes->get('mutasi/create', 'MutasiController::create');
$routes->post('mutasi/store', 'MutasiController::store');
$routes->get('mutasi/detail/(:num)', 'MutasiController::detail/$1');
$routes->get('mutasi/export/excel', 'MutasiController::exportExcel');
$routes->get('mutasi/export/pdf', 'MutasiController::exportPDF');

// ✅ PEMINJAMAN
$routes->get('peminjaman', 'PeminjamanController::index');
$routes->get('peminjaman/create', 'PeminjamanController::create');
$routes->post('peminjaman/store', 'PeminjamanController::store');
$routes->get('peminjaman/detail/(:num)', 'PeminjamanController::detail/$1');
$routes->get('peminjaman/export/excel', 'PeminjamanController::exportExcel');
$routes->get('peminjaman/export/pdf', 'PeminjamanController::exportPDF');

// ✅ PENGEMBALIAN
$routes->get('pengembalian', 'PengembalianController::index');
$routes->get('pengembalian/detail/(:num)', 'PengembalianController::detail/$1');
$routes->post('pengembalian/store', 'PengembalianController::store');
$routes->get('pengembalian/export/excel', 'PengembalianController::exportExcel');
$routes->get('pengembalian/export/pdf', 'PengembalianController::exportPDF');

// ✅ LOG LOGIN
$routes->get('log-login', 'LogLoginController::index');
$routes->get('log-login/detail/(:num)', 'LogLoginController::detail/$1');

// ✅ PENGECEKAN
$routes->get('pengecekan', 'PengecekanController::index');
$routes->get('pengecekan/create', 'PengecekanController::create');
$routes->post('pengecekan/store', 'PengecekanController::store');
$routes->get('pengecekan/export/excel', 'PengecekanController::exportExcel');
$routes->get('pengecekan/export/pdf', 'PengecekanController::exportPDF');

// ✅ PENEMPATAN
$routes->get('penempatan', 'PenempatanController::index');
$routes->get('penempatan/create', 'PenempatanController::create');
$routes->get('penempatan/edit/(:num)', 'PenempatanController::edit/$1');
$routes->post('penempatan/store', 'PenempatanController::store');
$routes->get('penempatan/detail/(:num)', 'PenempatanController::detail/$1');

// ✅ LOKASI
$routes->get('lokasi', 'LokasiController::index');
$routes->get('lokasi/create', 'LokasiController::create');
$routes->post('lokasi/store', 'LokasiController::store');
$routes->get('lokasi/edit/(:num)', 'LokasiController::edit/$1');
$routes->post('lokasi/update/(:num)', 'LokasiController::update/$1');
$routes->get('lokasi/delete/(:num)', 'LokasiController::delete/$1');
$routes->get('lokasi/detail/(:num)', 'LokasiController::detail/$1');
$routes->get('lokasi/export/excel', 'LokasiController::exportExcel');
$routes->get('lokasi/export/pdf', 'LokasiController::exportPDF');

// ✅ USER (Manajemen User)
$routes->get('user', 'UserController::index');
$routes->get('user/create', 'UserController::create');
$routes->post('user/store', 'UserController::store');
$routes->get('user/edit/(:num)', 'UserController::edit/$1');
$routes->post('user/update/(:num)', 'UserController::update/$1');
$routes->get('user/delete/(:num)', 'UserController::delete/$1');
$routes->get('user/detail/(:num)', 'UserController::detail/$1');
$routes->get('user/password', 'UserController::changePassword');
$routes->post('user/password', 'UserController::updatePassword');
$routes->get('user/export/excel', 'UserController::exportExcel');
$routes->get('user/export/pdf', 'UserController::exportPDF');

// ✅ SETTING SISTEM
$routes->get('setting', 'SettingController::index');
$routes->post('setting/update', 'SettingController::update');

// ✅ API NOTIFIKASI
$routes->group('api', function($routes) {
    $routes->get('notifikasi', 'api\\NotifikasiApi::index');
    $routes->get('notifikasi/(:num)', 'api\\NotifikasiApi::show/$1');
    $routes->post('notifikasi', 'api\\NotifikasiApi::create');
    $routes->put('notifikasi/(:num)', 'api\\NotifikasiApi::update/$1');
    $routes->delete('notifikasi/(:num)', 'api\\NotifikasiApi::delete/$1');
});

$routes->get('debug-password', 'DebugController::index');
