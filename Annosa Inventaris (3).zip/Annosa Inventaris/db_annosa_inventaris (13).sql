-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 01, 2025 at 10:53 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_annosa_inventaris`
--

-- --------------------------------------------------------

--
-- Table structure for table `barang`
--

CREATE TABLE `barang` (
  `id` int(11) NOT NULL,
  `nama_barang` varchar(100) DEFAULT NULL,
  `kode_barang` varchar(50) DEFAULT NULL,
  `merk` varchar(100) DEFAULT NULL,
  `model` varchar(100) DEFAULT NULL,
  `warna` varchar(50) DEFAULT NULL,
  `spesifikasi` text DEFAULT NULL,
  `foto` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `barang`
--

INSERT INTO `barang` (`id`, `nama_barang`, `kode_barang`, `merk`, `model`, `warna`, `spesifikasi`, `foto`) VALUES
(1, 'Meja Kerja', 'MBL-2024-015', 'Olympic', 'OK-880', 'Pink', 'Meja kayu untuk kantor', NULL),
(2, 'Kursi Kantor', 'MBL-2024-016', 'Chairman', 'CT-35', 'Hitam', 'Kursi ergonomis untuk kerja', NULL),
(4, 'buku ', '4', 'Aqua', 'monuo', 'putih', 'bububu', '1751198217_027554ee9ebe9a1d020a.jpg'),
(5, 'laptop', 'BRGOO1', 'ASUS', 'VivoBook A14', 'silver', 'RAM 8GB, SSD 512GB', '1751356480_50683f426571d485a6df.png'),
(6, 'Proyektor', 'BRGOO2', 'Epson', 'EB-X41', 'putih', 'XGA 3600 lumens', '1751356756_017dcf2db7caea776ecc.png');

-- --------------------------------------------------------

--
-- Table structure for table `inventaris`
--

CREATE TABLE `inventaris` (
  `id` int(11) NOT NULL,
  `barang_id` int(11) DEFAULT NULL,
  `lokasi_id` int(11) DEFAULT NULL,
  `kondisi` varchar(50) DEFAULT NULL,
  `jumlah` int(11) DEFAULT NULL,
  `tanggal_masuk` date DEFAULT NULL,
  `sumber_dana` varchar(100) DEFAULT NULL,
  `tahun_anggaran` year(4) DEFAULT NULL,
  `keterangan` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `inventaris`
--

INSERT INTO `inventaris` (`id`, `barang_id`, `lokasi_id`, `kondisi`, `jumlah`, `tanggal_masuk`, `sumber_dana`, `tahun_anggaran`, `keterangan`) VALUES
(1, 1, 1, 'Baik', 1, '2024-03-01', 'Dana Internal Kantor', '2024', 'Digunakan saat rapat staf'),
(2, 2, 1, 'Baik', 1, '2024-03-02', 'Dana Internal Kantor', '2024', 'Digunakan saat rapat staf');

-- --------------------------------------------------------

--
-- Table structure for table `label`
--

CREATE TABLE `label` (
  `id` int(11) NOT NULL,
  `id_inventaris` int(11) NOT NULL,
  `nama_barang` varchar(100) NOT NULL,
  `kode_inventaris` varchar(100) NOT NULL,
  `kategori` varchar(100) NOT NULL,
  `lokasi` varchar(100) NOT NULL,
  `tahun` year(4) NOT NULL,
  `tgl_cetak` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `log_login`
--

CREATE TABLE `log_login` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `waktu_login` datetime DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `status_login` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lokasi`
--

CREATE TABLE `lokasi` (
  `id` int(11) NOT NULL,
  `ruangan` varchar(100) DEFAULT NULL,
  `lantai` varchar(50) DEFAULT NULL,
  `gedung` varchar(100) DEFAULT NULL,
  `status` enum('Aktif','Tidak Aktif') DEFAULT 'Aktif'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `lokasi`
--

INSERT INTO `lokasi` (`id`, `ruangan`, `lantai`, `gedung`, `status`) VALUES
(1, 'Ruang Staf', '1', 'Gedung Utama', 'Aktif'),
(2, 'Ruang TU', '2', 'Gedung A', 'Aktif');

-- --------------------------------------------------------

--
-- Table structure for table `mutasi`
--

CREATE TABLE `mutasi` (
  `id` int(11) NOT NULL,
  `inventaris_id` int(11) DEFAULT NULL,
  `tanggal` date DEFAULT NULL,
  `lokasi_awal_id` int(11) DEFAULT NULL,
  `lokasi_tujuan_id` int(11) DEFAULT NULL,
  `tahun_anggaran` year(4) DEFAULT NULL,
  `keterangan` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `mutasi`
--

INSERT INTO `mutasi` (`id`, `inventaris_id`, `tanggal`, `lokasi_awal_id`, `lokasi_tujuan_id`, `tahun_anggaran`, `keterangan`) VALUES
(1, 1, '2025-06-30', 2, 1, '2004', 'mjmmmj'),
(2, 1, '2025-06-30', 2, 1, '2004', 'mjmmmj');

-- --------------------------------------------------------

--
-- Table structure for table `peminjaman`
--

CREATE TABLE `peminjaman` (
  `id` int(11) NOT NULL,
  `kode_peminjaman` varchar(50) DEFAULT NULL,
  `nama_peminjam` varchar(100) DEFAULT NULL,
  `nomor_identitas` varchar(50) DEFAULT NULL,
  `tanggal_pinjam` date DEFAULT NULL,
  `tanggal_kembali` date DEFAULT NULL,
  `inventaris_id` int(11) DEFAULT NULL,
  `jumlah` int(11) DEFAULT NULL,
  `keperluan` text DEFAULT NULL,
  `status` enum('Sedang Dipinjam','Sudah Dikembalikan') DEFAULT 'Sedang Dipinjam',
  `petugas_input` varchar(100) DEFAULT NULL,
  `verifikasi` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `penempatan`
--

CREATE TABLE `penempatan` (
  `id` int(11) NOT NULL,
  `inventaris_id` int(11) DEFAULT NULL,
  `tanggal` date DEFAULT NULL,
  `lokasi_id` int(11) DEFAULT NULL,
  `keterangan` text DEFAULT NULL,
  `tahun_anggaran` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `penempatan`
--

INSERT INTO `penempatan` (`id`, `inventaris_id`, `tanggal`, `lokasi_id`, `keterangan`, `tahun_anggaran`) VALUES
(1, 1, '2025-06-29', 1, 'monster', '2003'),
(2, 2, '2025-06-29', 2, 'aqaqaqaqq', '2007');

-- --------------------------------------------------------

--
-- Table structure for table `pengecekan`
--

CREATE TABLE `pengecekan` (
  `id` int(11) NOT NULL,
  `inventaris_id` int(11) DEFAULT NULL,
  `tahun_perolehan` year(4) DEFAULT NULL,
  `kondisi` varchar(50) DEFAULT NULL,
  `dana` varchar(100) DEFAULT NULL,
  `catatan` text DEFAULT NULL,
  `tanggal_cek` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pengembalian`
--

CREATE TABLE `pengembalian` (
  `id` int(11) NOT NULL,
  `kode_pengembalian` varchar(50) DEFAULT NULL,
  `peminjaman_id` int(11) DEFAULT NULL,
  `tanggal_pengembalian` date DEFAULT NULL,
  `jumlah_kembali` int(11) DEFAULT NULL,
  `kondisi_kembali` varchar(100) DEFAULT NULL,
  `catatan_kembali` text DEFAULT NULL,
  `status` enum('Sudah Dikembalikan') DEFAULT 'Sudah Dikembalikan',
  `petugas_terima` varchar(100) DEFAULT NULL,
  `verifikasi` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `setting`
--

CREATE TABLE `setting` (
  `id` int(11) NOT NULL,
  `key` varchar(100) NOT NULL,
  `value` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `level` enum('Admin','User') DEFAULT 'User',
  `status` enum('Aktif','Tidak Aktif') DEFAULT 'Aktif'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `password`, `level`, `status`) VALUES
(1, 'samsul', '$2y$10$HoR97FDnvT1GhY6uwjdCGOLc6aGZ3gXaT4oC7zTrctI7nnGUWXglW', 'User', 'Aktif'),
(2, 'samsulo', '$2y$10$hMUz2Rep5jguIDsImeeW5upmSAEyTrx2gzMx21QlyTE/y0uiCrTuS', 'User', 'Aktif'),
(6, 'aloguys', '$2y$10$lj0iIl7oVuVebCR4NqwiX.b3V5qEz7gsU.7XeQf0o7wXiWxBUrNzq', 'Admin', 'Aktif'),
(8, 'aloguyso', '$2y$10$d/yWEveJhIpo7LYuASOdaOEweBkYW8lI5KHgKa78GZ5bdZrLQ.HFO', 'Admin', 'Aktif'),
(9, 'okelah', '$2y$10$XC9qqxTJfo6Y4m1fWAa0BeJ8qbjM0rJ2SYzjA1v8mQMrRPgqe3pYC', 'User', 'Aktif');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `barang`
--
ALTER TABLE `barang`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `inventaris`
--
ALTER TABLE `inventaris`
  ADD PRIMARY KEY (`id`),
  ADD KEY `barang_id` (`barang_id`),
  ADD KEY `lokasi_id` (`lokasi_id`);

--
-- Indexes for table `label`
--
ALTER TABLE `label`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_inventaris` (`id_inventaris`);

--
-- Indexes for table `log_login`
--
ALTER TABLE `log_login`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `lokasi`
--
ALTER TABLE `lokasi`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mutasi`
--
ALTER TABLE `mutasi`
  ADD PRIMARY KEY (`id`),
  ADD KEY `inventaris_id` (`inventaris_id`),
  ADD KEY `lokasi_awal_id` (`lokasi_awal_id`),
  ADD KEY `lokasi_tujuan_id` (`lokasi_tujuan_id`);

--
-- Indexes for table `peminjaman`
--
ALTER TABLE `peminjaman`
  ADD PRIMARY KEY (`id`),
  ADD KEY `inventaris_id` (`inventaris_id`);

--
-- Indexes for table `penempatan`
--
ALTER TABLE `penempatan`
  ADD PRIMARY KEY (`id`),
  ADD KEY `inventaris_id` (`inventaris_id`),
  ADD KEY `lokasi_id` (`lokasi_id`);

--
-- Indexes for table `pengecekan`
--
ALTER TABLE `pengecekan`
  ADD PRIMARY KEY (`id`),
  ADD KEY `inventaris_id` (`inventaris_id`);

--
-- Indexes for table `pengembalian`
--
ALTER TABLE `pengembalian`
  ADD PRIMARY KEY (`id`),
  ADD KEY `peminjaman_id` (`peminjaman_id`);

--
-- Indexes for table `setting`
--
ALTER TABLE `setting`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `key` (`key`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `barang`
--
ALTER TABLE `barang`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `inventaris`
--
ALTER TABLE `inventaris`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `label`
--
ALTER TABLE `label`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `log_login`
--
ALTER TABLE `log_login`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lokasi`
--
ALTER TABLE `lokasi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `mutasi`
--
ALTER TABLE `mutasi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `peminjaman`
--
ALTER TABLE `peminjaman`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `penempatan`
--
ALTER TABLE `penempatan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `pengecekan`
--
ALTER TABLE `pengecekan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pengembalian`
--
ALTER TABLE `pengembalian`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `setting`
--
ALTER TABLE `setting`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `inventaris`
--
ALTER TABLE `inventaris`
  ADD CONSTRAINT `inventaris_ibfk_1` FOREIGN KEY (`barang_id`) REFERENCES `barang` (`id`),
  ADD CONSTRAINT `inventaris_ibfk_2` FOREIGN KEY (`lokasi_id`) REFERENCES `lokasi` (`id`);

--
-- Constraints for table `log_login`
--
ALTER TABLE `log_login`
  ADD CONSTRAINT `log_login_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`);

--
-- Constraints for table `mutasi`
--
ALTER TABLE `mutasi`
  ADD CONSTRAINT `mutasi_ibfk_1` FOREIGN KEY (`inventaris_id`) REFERENCES `inventaris` (`id`),
  ADD CONSTRAINT `mutasi_ibfk_2` FOREIGN KEY (`lokasi_awal_id`) REFERENCES `lokasi` (`id`),
  ADD CONSTRAINT `mutasi_ibfk_3` FOREIGN KEY (`lokasi_tujuan_id`) REFERENCES `lokasi` (`id`);

--
-- Constraints for table `peminjaman`
--
ALTER TABLE `peminjaman`
  ADD CONSTRAINT `peminjaman_ibfk_1` FOREIGN KEY (`inventaris_id`) REFERENCES `inventaris` (`id`);

--
-- Constraints for table `penempatan`
--
ALTER TABLE `penempatan`
  ADD CONSTRAINT `penempatan_ibfk_1` FOREIGN KEY (`inventaris_id`) REFERENCES `inventaris` (`id`),
  ADD CONSTRAINT `penempatan_ibfk_2` FOREIGN KEY (`lokasi_id`) REFERENCES `lokasi` (`id`);

--
-- Constraints for table `pengecekan`
--
ALTER TABLE `pengecekan`
  ADD CONSTRAINT `pengecekan_ibfk_1` FOREIGN KEY (`inventaris_id`) REFERENCES `inventaris` (`id`);

--
-- Constraints for table `pengembalian`
--
ALTER TABLE `pengembalian`
  ADD CONSTRAINT `pengembalian_ibfk_1` FOREIGN KEY (`peminjaman_id`) REFERENCES `peminjaman` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
